package Controller.App;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.awt.*;

public class MainApps extends Application {
    private Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    private double screenWidth = screenSize.getWidth();
    private double screenHeight = screenSize.getHeight();
    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader splashLoader = new FXMLLoader(getClass().getResource("/fxml/Pages/MenuAdmin.fxml"));
        Scene splashScene = new Scene(splashLoader.load(), screenWidth-5, screenHeight-25);
        primaryStage.setScene(splashScene);
        primaryStage.setMinWidth(screenWidth-5);
        primaryStage.setMinHeight(screenHeight-25);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
