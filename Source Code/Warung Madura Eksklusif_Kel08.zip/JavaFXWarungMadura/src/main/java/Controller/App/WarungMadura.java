package Controller.App;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class WarungMadura implements Initializable {
    boolean login_open = false;
    @FXML
    public StackPane splash_screen;
    @FXML
    ProgressBar progress_bar;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        progress_bar.setStyle("-fx-accent: #053B50; -fx-background-color: #053B50; -fx-border-color: #FFFFFF; -fx-border-radius: 6px;  -fx-border-width: 0px;");
        animateProgressBar();
    }

    private void animateProgressBar() {
        progress_bar.setProgress(0);
        int totalDuration = 4000;
        int updateInterval = 10;
        double increment = updateInterval / (double) totalDuration;

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(updateInterval), event -> {
                    double currentProgress = progress_bar.getProgress();
                    progress_bar.setProgress(Math.min(1, currentProgress + increment));
                })
        );
        timeline.setCycleCount(totalDuration / updateInterval);
        timeline.play();
    }

    @FXML
    private void testingsetpage() {
        if (!login_open) {
            login_open = true;
            Parent fxml = null;
            try {
                fxml = FXMLLoader.load(getClass().getResource("/fxml/LandingPage/Login.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            splash_screen.getChildren().removeAll();
            splash_screen.getChildren().setAll(fxml);
        }
    }
}
