package Controller.Component;

import Connection.DBConnect;
import Controller.MasterC.DiscountC;
import Master.MemberRoyalty;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javax.swing.*;
import java.sql.SQLException;

public class DiscountCard extends Controller{
    @FXML
    Label id_disc, name_discount, discount_Royalty;
    @FXML
    Button btn_info, btn_delete, btn_update;
    DiscountC discountController;
    MemberRoyalty royal = new MemberRoyalty();
    private int id;

    public void setController(DiscountC discountController) {
        this.discountController = discountController;
    }
    public void dicountCard(int id, String name, int idMember) {
        this.id = id;
        id_disc.setText(String.format("DSC%02d", id));
        name_discount.setText(name);
        discount_Royalty.setText(royal.getNameCategoryMember(idMember));
    }
    public void info(){
        discountController.openInfo(id);
    }

    public void update(){
            discountController.setBtn(id);
            discountController.setIdDsc(id);
    }
    public void delete(){
        discountController.deleteData(id);
    }
}