package Controller.Component;

import Master.Position;
import SuperClassInterface.Controller;
import Controller.MasterC.EmployeeC;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class EmployeeCard extends Controller {
    @FXML
    Label id_emp, name_emp, position_emp;
    @FXML
    Button btn_info, btn_delete, btn_update;
    EmployeeC employeeController;
    Position ps = new Position();
    private int id;

    @Override
    public void setController(EmployeeC employeeController) {
        this.employeeController = employeeController;
    }

    public void employeeDataCard(int id, String name, int idJabatan) {
        this.id = id;
        id_emp.setText(String.format("EMP%02d", id));
        name_emp.setText(name);
        position_emp.setText(ps.getNamePosition(idJabatan));
    }

    public void info() {
        employeeController.openInfo(id);
    }

    public void update() {
        employeeController.setBtn(id);
        employeeController.setIdEmp(id);
    }

    public void delete() {
        employeeController.deleteData(id);
    }

}