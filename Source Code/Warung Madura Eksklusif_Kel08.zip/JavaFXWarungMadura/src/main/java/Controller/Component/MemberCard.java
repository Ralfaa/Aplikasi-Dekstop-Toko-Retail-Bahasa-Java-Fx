package Controller.Component;

import Connection.DBConnect;
import Controller.MasterC.MemberC;
import Master.MemberRoyalty;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javax.swing.*;
import java.sql.SQLException;

public class MemberCard extends Controller {
    @FXML
    Label id_member, name_member, member_point, member_royalty;
    @FXML
    Button btn_info, btn_delete, btn_update;
    MemberC memberController;
    MemberRoyalty royal = new MemberRoyalty();
    private int id;

    public void setController(MemberC memberController) {
        this.memberController = memberController;
    }

    public void memberDataCard(int id, String name, int idJMember, int point) {
        this.id = id;
        id_member.setText(String.format("MBR%03d", id));
        name_member.setText(name);
        member_point.setText(Integer.toString(point));
        member_royalty.setText(royal.getNameCategoryMember(idJMember));
    }

    public void info() {
        memberController.openInfo(id);
    }

    public void update() {
        memberController.setBtn(id);
        memberController.setIdMember(id);
    }

    public void delete() {
        memberController.deleteData(id);
    }

}