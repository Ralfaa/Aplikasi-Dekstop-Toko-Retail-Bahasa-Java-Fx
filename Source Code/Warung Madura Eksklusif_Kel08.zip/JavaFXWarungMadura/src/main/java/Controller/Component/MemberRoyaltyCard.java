package Controller.Component;


import Connection.DBConnect;
import Controller.MasterC.MemberRoyaltyC;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javax.swing.*;
import java.sql.SQLException;

public class MemberRoyaltyCard extends Controller {
    @FXML
    Label id_pos, name_pos, point_poss;
    @FXML
    Button btn_info, btn_delete, btn_update;
    MemberRoyaltyC memberRoyaltyC;
    private int id;

    public void setController(MemberRoyaltyC controller) {
        this.memberRoyaltyC = controller;
    }

    public void MemberRoyaltyDataCard(int id, String name, int MPoint) {
        this.id = id;
        id_pos.setText(String.format("MRY%02d", id));
        point_poss.setText((Integer.toString(MPoint)));
        name_pos.setText(name);
    }

    public void info() {
        memberRoyaltyC.openInfo(id);
    }

    public void update() {
        memberRoyaltyC.setBtn(id);
        memberRoyaltyC.setIdRoyalty(id);

    }

    public void delete() {
        memberRoyaltyC.deleteData(id);
    }

}
