package Controller.Component;


import Connection.DBConnect;
import SuperClassInterface.Controller;
import Controller.MasterC.PositionC;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import javax.swing.*;
import java.sql.SQLException;

public class PositionCard extends Controller{
    @FXML
    Label id_pos, name_pos, permission_pos;
    @FXML
    Button btn_info, btn_delete, btn_update;
    PositionC positionController;
    DBConnect connect = new DBConnect();
    private int id;

    @Override
    public void setController(PositionC controller) {
        this.positionController = controller;
    }

    public void positionDataCard(int id, String name, String permission) {
        this.id = id;
        id_pos.setText(String.format("PST%02d", id));
        permission_pos.setText(permission);
        name_pos.setText(name);
    }
    public void info(){
        positionController.openInfo(id);
    }
    public void update() {
            positionController.setBtn(id);
            positionController.setIdPst(id);
    }
    public void delete(){
        positionController.deleteData(id);
    }

}
