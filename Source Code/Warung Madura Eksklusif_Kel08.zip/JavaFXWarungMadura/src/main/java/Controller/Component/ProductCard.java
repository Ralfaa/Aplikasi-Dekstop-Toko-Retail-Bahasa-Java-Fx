package Controller.Component;

import Connection.DBConnect;
import Controller.MasterC.ProductC;
import Master.ProductCategory;
import Master.Supplier;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javax.swing.*;
import java.sql.SQLException;

public class ProductCard extends Controller {
    @FXML
    Label id_Pr, name_Pr, supplier_Pr, category_Pr;
    @FXML
    Button btn_info, btn_delete, btn_update;
    ProductC productController;
    ProductCategory pc = new ProductCategory();
    Supplier sp = new Supplier();
    private int id;

    @Override
    public void setController(ProductC productController) {
        this.productController = productController;
    }

    public void productDataCard(int id, int idSupplier, int idCategory, String name) {
        this.id = id;
        id_Pr.setText(String.format("PRD%02d", id));
        name_Pr.setText(name);
        category_Pr.setText(pc.getNameCategories(idCategory));
        supplier_Pr.setText(sp.getNameSupplier(idSupplier));
    }

    public void info() {
        productController.openInfo(id);
    }

    public void update() {
        productController.setBtn(id);
        productController.setIdPrd(id);
    }

    public void delete() {
        productController.deleteData(id);
    }
}