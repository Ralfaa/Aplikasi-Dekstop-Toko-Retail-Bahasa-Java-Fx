package Controller.Component;

import Controller.MasterC.ProductCategoryC;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
public class ProductCategoryCard extends Controller {
    @FXML
    Label id_Cp, name_Cp, unit_Cp;
    @FXML
    Button btn_info, btn_delete, btn_update;
    ProductCategoryC productCategoryController;
    private int id;

    @Override
    public void setController(ProductCategoryC controller) {
        this.productCategoryController = controller;
    }

    public void productCategoryDataCard(int id, String name, String Unit) {
        this.id = id;
        id_Cp.setText(String.format("UNT%02d", id));
        name_Cp.setText(name);
        unit_Cp.setText(Unit);
    }

    public void info() {
        productCategoryController.openInfo(id);
    }

    public void update() {
        productCategoryController.setBtn(id);
        productCategoryController.setIdPct(id);
    }

    public void delete() {
        productCategoryController.deleteData(id);
    }
}
