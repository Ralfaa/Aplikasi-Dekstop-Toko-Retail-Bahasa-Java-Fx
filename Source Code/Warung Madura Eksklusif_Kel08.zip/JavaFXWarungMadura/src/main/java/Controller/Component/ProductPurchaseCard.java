package Controller.Component;

import Controller.TransactionC.PurchaseC;
import Master.Product;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class ProductPurchaseCard extends Controller {
    @FXML
    Label id_Pr, name_Pr, stock_Pr;
    @FXML
    Button btn_info, btn_delete, btn_add;
    PurchaseC purchaseC;
    private int id;
    Product prd = new Product();
    public void initialize(){

    }
    @Override
    public void setController(PurchaseC controller) {
        this.purchaseC = controller;
    }
    public void productDataCard(int id, String name, int stock) {
        this.id = id;
        addTrs(id);
        id_Pr.setText(String.format("PRD%02d", id));
        name_Pr.setText(name);
        stock_Pr.setText(String.valueOf(stock));
    }
    public void info(){
        purchaseC.openInfo(id);
    }
    public void setBtn(int id){
        if(id == 0){
            btn_delete.setDisable(true);
        }
    }
    public void addTrs(int id){
        btn_add.setOnAction(event -> {
                purchaseC.loadList(id);
        });
    }
}
