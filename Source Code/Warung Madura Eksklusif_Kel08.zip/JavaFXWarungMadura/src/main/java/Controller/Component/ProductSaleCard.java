package Controller.Component;

import Controller.TransactionC.SaleC;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import java.io.*;
public class ProductSaleCard extends Controller {
    @FXML
    VBox vbCard;
    @FXML
    StackPane spCard;
    @FXML
    ImageView imgCard;
    @FXML
    Label lbCardNama, lbCardHarga;
    SaleC saleC;

    public void initialize() {

    }

    public void setController(SaleC controller) {
        this.saleC = controller;
    }

    public void productPurchaseCard(int id, String nama, double harga, byte[] image) {
        lbCardNama.setText(nama);
        addTrs(id);
        lbCardHarga.setText(formatRp(harga));
        if (image != null) {
            InputStream input = new ByteArrayInputStream(image);
            Image img = new Image(input);
            imgCard.setImage(img);
        } else {
            imgCard.setImage(null);
        }
    }

    public void addTrs(int id) {
        vbCard.setOnMouseClicked(mouseEvent -> {
            saleC.loadList(id);
        });
    }
}
