package Controller.Component;

import Controller.TransactionC.PurchaseC;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;

import java.util.List;

public class PurchaseCard extends Controller {
    @FXML
    Label lbName, lbharga;
    @FXML
    Pane paneList;
    @FXML
    Button btnAdd, btnDecrease;
    @FXML
    TextField tfValue;
    PurchaseC purchaseC;
    private double total, hargaBeli;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getTotal() {return total;}
    public void setTotal(double total) {this.total = total;}
    public double getHargaBeli() {return hargaBeli;}
    public void setHargaBeli(double hargaBeli) {this.hargaBeli = hargaBeli;}

    public void initialize() {
        handleStock();
        tfValue.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
    }
    public void enterQty(){
        updateQty(Integer.parseInt(tfValue.getText()));
        purchaseC.lbHarga(total());
    }

    public void productDataCard(int id, String name, double hargaBeli, int stock) {
        lbName.setText(name);
        this.id = id;
        lbharga.setText(formatRp(hargaBeli));
        updateQty(Integer.parseInt(tfValue.getText()));
        purchaseC.lbHarga(total());
        this.hargaBeli = hargaBeli;
    }
    @Override
    public void setController(PurchaseC controller) {
        this.purchaseC = controller;
    }
    public void delete(){
        purchaseC.deleteList(paneList);
        purchaseC.lbHarga(total());
    }
    public void updateQty(int val){
        for (int i = 0; i < PurchaseC.product.size();i++){
            PurchaseC.DataPembelian sd = PurchaseC.product.get(i);
            if (sd.getProduk().getIdProduct() == getId()){
                sd.setQty(val);
                PurchaseC.product.set(i, sd);
                break;
            }
        }
    }
    public void handleStock(){
        btnAdd.setOnAction(event -> {
            int value = Integer.parseInt(tfValue.getText());
            value++;
            tfValue.setText(String.valueOf(value));
            updateQty(value);
            purchaseC.lbHarga(total());
        });
        btnDecrease.setOnAction(event -> {
            int value = Integer.parseInt(tfValue.getText());
            if(value > 1){
                value--;
                tfValue.setText(String.valueOf(value));
                updateQty(value);
                purchaseC.lbHarga(total());
            }
        });
    }
    public double total(){
        double total = 0;
        List<PurchaseC.DataPembelian> listPembelian = PurchaseC.product;

        for (int i = 0; i < listPembelian.size(); i++){
            PurchaseC.DataPembelian bl = listPembelian.get(i);
            total+=bl.getProduk().getPurchasePrice()*bl.getQty();
        }
        return total;
    }
}
