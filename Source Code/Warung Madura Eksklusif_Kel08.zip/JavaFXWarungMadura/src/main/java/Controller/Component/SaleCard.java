package Controller.Component;

import Controller.TransactionC.PurchaseC;
import Controller.TransactionC.SaleC;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

import java.util.List;

public class SaleCard extends Controller {
    @FXML
    Label lbName, lbharga, lbhargaawal;
    @FXML
    Pane paneList;
    @FXML
    Button btnAdd, btnDecrease;
    @FXML
    TextField tfValue;
    SaleC saleC;
    private double total, hargaBeli;
    private int id, persentase, stock;
    private String name;

    public int getId() {return id;}
    public void setId(int id) {this.id = id;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
    public int getPersentase() {return persentase;}
    public void setPersentase(int persentase) {this.persentase = persentase;}

    public int getStock() {return stock;}
    public void setStock(int stock) {this.stock = stock;}
    public double getTotal() {return total;}
    public void setTotal(double total) {this.total = total;}
    public double getHargaBeli() {return hargaBeli;}
    public void setHargaBeli(double hargaBeli) {this.hargaBeli = hargaBeli;}

    public void initialize() {
        handleStock();
        tfValue.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
    }

    public void enterQty(){
        if(Integer.parseInt(tfValue.getText()) <= stock){
            updateQty(Integer.parseInt(tfValue.getText()));
            saleC.lbHarga(total());
        }else{
            tfValue.setText(String.valueOf(stock));
            updateQty(Integer.parseInt(tfValue.getText()));
            saleC.lbHarga(total());
        }
    }

    public void productDataCard(int id, String name, int persentase, double hargaBeli, int stock) {
        this.id = id;
        lbName.setText(name);
        lbharga.setText(formatRp(hargaDiskon(hargaBeli, persentase)));
        this.persentase = persentase;
        this.stock = stock;
        lbharga.setStyle("-fx-strikethrough: true;");
        Text text = new Text();
        text.setFont(Font.font("Arial", FontPosture.REGULAR, 10));
        text.setText(formatRp(hargaBeli));
        text.setLayoutY(55);
        text.setLayoutX(46);
        text.setStrikethrough(true);
        updateQty(Integer.parseInt(tfValue.getText()));
        saleC.lbHarga(total());
        paneList.getChildren().add(text);
    }
    public double hargaDiskon(double hargaBeli, int persentase){
        double harga = hargaBeli *(persentase / 100.0);
        return hargaBeli - harga;
    }
    public void setController(SaleC controller) {
        this.saleC = controller;
    }
    public void delete(){
        saleC.deleteList(paneList);
        saleC.lbHarga(total());
    }
    public void updateQty(int val){
        for (int i = 0; i < SaleC.product.size();i++){
            SaleC.DataPenjualan sd = SaleC.product.get(i);
            if (sd.getProduk().getIdProduct() == getId()){
                sd.setQty(val);
                SaleC.product.set(i, sd);
                break;
            }
        }
    }
    public void handleStock(){
        btnAdd.setOnAction(event -> {
            if(Integer.parseInt(tfValue.getText())==stock){
                btnAdd.setDisable(false);
            }else{
                int value = Integer.parseInt(tfValue.getText());
                value++;
                tfValue.setText(String.valueOf(value));
                updateQty(value);
                saleC.lbHarga(total());
            }
        });
        btnDecrease.setOnAction(event -> {
            int value = Integer.parseInt(tfValue.getText());
            if(value > 1){
                value--;
                tfValue.setText(String.valueOf(value));
                updateQty(value);
                saleC.lbHarga(total());
            }
        });
    }
    public double total(){
        double total = 0;
        List<SaleC.DataPenjualan> listPembelian = SaleC.product;

        for (int i = 0; i < listPembelian.size(); i++){
            SaleC.DataPenjualan bl = listPembelian.get(i);
            total+=hargaDiskon(bl.getProduk().getSellingPrice(),bl.getProduk().getPromo())*bl.getQty();
        }
        return total;
    }
}
