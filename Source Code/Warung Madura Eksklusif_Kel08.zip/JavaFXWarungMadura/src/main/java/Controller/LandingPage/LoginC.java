package Controller.LandingPage;

import Connection.DBConnect;
import Controller.Pages.*;
import SuperClassInterface.Controller;
import javafx.fxml.*;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import java.io.IOException;
import java.sql.SQLException;

public class LoginC extends Controller {
    @FXML
    private PasswordField pfPw;
    @FXML
    private TextField tfPw, tfUser;
    @FXML
    private Button handlePw, btnLogin   ;
    @FXML
    private ImageView eyeIcon;
    @FXML
    Pane popop_success, popop_warning;
    @FXML
    Label deskSuccess, deskWarning;
    @FXML
    private StackPane main_login;
    @FXML
    private boolean show;
    DBConnect connect = new DBConnect();

    @FXML
    public void initialize() {
        tfPw.textProperty().bindBidirectional(pfPw.textProperty());
        setIcon();
    }

    @FXML
    public void showPw() {
        show = !show;
        tfPw.textProperty().bindBidirectional(pfPw.textProperty());
        if (show) {
            tfPw.setManaged(true);
            tfPw.setVisible(true);
            pfPw.setVisible(false);
            pfPw.setManaged(false);
        } else {
            tfPw.setManaged(false);
            tfPw.setVisible(false);
            pfPw.setVisible(true);
            pfPw.setManaged(true);
        }
        setIcon();
    }

    public void setIcon() {
        String iconPath = show ? "/assets/Icon/view.png" : "/assets/Icon/hide.png";
        eyeIcon.setImage(new Image(getClass().getResourceAsStream(iconPath)));
    }

    public void handleLogin(javafx.event.ActionEvent e) throws IOException {
        User Karyawan = checkAccount(tfUser.getText(), pfPw.getText());
        if (tfUser.getText().isEmpty()|| pfPw.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "All column must be filled");
        } else if (Karyawan == null) {
            popup(popop_warning, deskWarning, "Invalid username or password");
            tfPw.setText("");
            tfUser.setText("");
        } else if (Karyawan.id > 0) {
            String jabatan = jabatan(Karyawan.id_jabatan);
            String path = page(jabatan);
            if (path.equals("No Access")) {
                popup(popop_warning, deskWarning, "You don`t have any access");
                return;
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(path));
            Parent fxml = loader.load();
            switch (jabatan) {
                case "Admin":
                    AdminC adminC = loader.getController();
                    adminC.getId(Karyawan.id);
                    break;
                case "Cashier":
                    CashierC cashierC = loader.getController();
                    cashierC.getId(Karyawan.id);
                    break;
                case "Manager":
                    ManagerC managerC = loader.getController();
                    managerC.getId(Karyawan.id);
                    break;
                default:
            }
            popup(popop_success, deskSuccess, "Login Successfully!!");
            main_login.getChildren().removeAll();
            main_login.getChildren().setAll(fxml);
            main_login.setAlignment(Pos.TOP_CENTER);
            main_login.setBackground(Background.fill(Color.WHITE));
        }
    }

    private User checkAccount(String userName, String password) {
        try {
            String user = "SELECT * from FnLogin(?, ?) AS id_karyawan";
            connect.pstat = connect.conn.prepareStatement(user);
            connect.pstat.setString(1, userName);
            connect.pstat.setString(2, password);
            connect.result = connect.pstat.executeQuery();
            if (connect.result.next()) {
                int id = connect.result.getInt("id_karyawan");
                int jabatan = connect.result.getInt("id_jabatan");
                String nama = connect.result.getString("NamaKaryawan");
                return new User(id, nama, jabatan);
            }
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return null;
    }

    private String jabatan(int id) {
        try {
            String jabatan = "SELECT dbo.FnGetAccess(?) AS AksesResult";
            connect.pstat = connect.conn.prepareStatement(jabatan);
            connect.pstat.setInt(1, id);
            connect.result = connect.pstat.executeQuery();
            if (connect.result.next()) {
                return connect.result.getString("AksesResult");
            }
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return null;
    }

    public String page(String Akses) {
        String path = "";
        switch (Akses) {
            case "Admin":
                path = "/fxml/Pages/MenuAdmin.fxml";
                break;
            case "Cashier":
                path = "/fxml/Pages/MenuCashier.fxml";
                break;
            case "Manager":
                path = "/fxml/Pages/MenuManager.fxml";
                break;
            default:
                return "No Access";
        }
        return path;
    }

    public static class User {
        public static int id;
        public static String Name;
        private int id_jabatan;

        public User(int id, String name, int idJabatan) {
            this.id = id;
            Name = name;
            id_jabatan = idJabatan;
        }

        public User(int id, int idJabatan) {
            this.id = id;
            id_jabatan = idJabatan;
        }

        public User() {

        }

        public int getId() {
            return id;
        }

        public String getName() {
            return Name;
        }

        public int getId_jabatan() {
            return id_jabatan;
        }
    }
}