package Controller.MasterC;

import Connection.DBConnect;
import Controller.Component.DiscountCard;
import Master.*;
import SuperClassInterface.*;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.util.Duration;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.*;

public class DiscountC extends Controller implements CRUD {
    @FXML
    VBox card_container, ap_kanan, vbkiri, vb_filter;
    @FXML
    Button btn_add, btn_upd2;
    @FXML
    HBox main, hb_add;
    @FXML
    GridPane vbform;
    @FXML
    AnchorPane detail_container, ap_atas, ap_kiri, main_content;
    @FXML
    TextField tfSearch, tfID, tfPDiscount, tfName, tfMAmount, dtID, dtStart, dtEnd, dtName, dtAmount, dtPercentage, dtMember;
    @FXML
    DatePicker EndDiscount, StartDiscount;
    @FXML
    TextArea taDeskripsi, dtDescription;
    @FXML
    ComboBox cbFilterType, cbFilterDiscount;
    @FXML
    ComboBox<DisplayedItem> cbMember;
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    Discount dsc = new Discount();
    MemberRoyalty royal = new MemberRoyalty();
    @FXML
    ScrollPane sp_view;
    TranslateTransition detail_card = new TranslateTransition();
    private ExecutorService executorService = Executors.newFixedThreadPool(1);

    DBConnect connect = new DBConnect();
    private int idDsc;

    public void setIdDsc(int idDsc) {
        this.idDsc = idDsc;
    }

    public void initialize() {
        loadData();
        loadMember();
        dsc.getIdDiscount(tfID);
//        tfMAmount.setOnKeyReleased(keyEvent -> {
//            formatRupiah(tfMAmount);
//        });
        tfMAmount.addEventFilter(KeyEvent.KEY_TYPED,this::setNumber);
        tfName.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        taDeskripsi.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        tfPDiscount.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
        cbFilterType.getItems().addAll("ID", "Name", "Jenis Member");
    }

    public void loadMember() {
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM JenisMember";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                cbFilterDiscount.getItems().add(connect.result.getString("nama"));
                cbMember.getItems().add(new DisplayedItem(connect.result.getString("nama"), connect.result.getString("id_jenis_member")));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
    }

    @Override
    public void insertData() {
        LocalDate startDate = StartDiscount.getValue();
        LocalDate endDate = EndDiscount.getValue();
        if (tfName.getText().isEmpty() || StartDiscount.getValue() == null
                || EndDiscount.getValue() == null || tfMAmount.getText().isEmpty()
                || tfPDiscount.getText().isEmpty() || taDeskripsi.getText().isEmpty()
                || cbMember.getValue() == null) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        } else if (startDate.isBefore(LocalDate.now()) || endDate.isBefore(startDate)||startDate.isAfter(endDate)) {
            popup(popop_warning, deskWarning, "Invalid Date!!");
        } else {
            connect.cstat = null;
            try {
                connect.cstat = connect.conn.prepareCall("{call SpInsertPromoDiskon(?,?,?,?,?,?,?,?)}");

                connect.cstat.setInt(1, Integer.parseInt(cbMember.getSelectionModel().getSelectedItem().getActualValue()));
                connect.cstat.setString(2, tfName.getText());
                connect.cstat.setString(3, taDeskripsi.getText());
                connect.cstat.setDate(4, Date.valueOf(StartDiscount.getValue()));
                connect.cstat.setDate(5, Date.valueOf(EndDiscount.getValue()));
                connect.cstat.setInt(6, Integer.parseInt(tfPDiscount.getText()));
                connect.cstat.setBigDecimal(7, parseRp(tfMAmount.getText(),1));
                connect.cstat.setInt(8, 1);
                connect.cstat.execute();
                popup(popop_success, deskSuccess, "Discount Inserted!!");
                loadData();
                clear();
                dsc.getIdDiscount(tfID);
            } catch (SQLException e) {
                alertError("Error :" + e.getMessage());
            }
        }
    }

    @Override
    public void updateData() {
        LocalDate startDate = StartDiscount.getValue();
        LocalDate endDate = EndDiscount.getValue();
        if (tfName.getText().isEmpty() || StartDiscount.getValue() == null
                || EndDiscount.getValue() == null || tfMAmount.getText().isEmpty()
                || tfPDiscount.getText().isEmpty() || taDeskripsi.getText().isEmpty()
                || cbMember.getValue() == null) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        } else if (startDate.isBefore(LocalDate.now()) || endDate.isBefore(startDate)||startDate.isAfter(endDate)) {
            popup(popop_warning, deskWarning, "Invalid Date!!");
        } else {
            try {
                connect.cstat = connect.conn.prepareCall("{call SpUpdatePromoDiskon(?,?,?,?,?,?,?,?,?)}");
                connect.cstat.setInt(1, Integer.parseInt(tfID.getText().substring(3)));
                connect.cstat.setInt(2, Integer.parseInt(cbMember.getSelectionModel().getSelectedItem().getActualValue()));
                connect.cstat.setString(3, tfName.getText());
                connect.cstat.setString(4, taDeskripsi.getText());
                connect.cstat.setDate(5, Date.valueOf(StartDiscount.getValue()));
                connect.cstat.setDate(6, Date.valueOf(EndDiscount.getValue()));
                connect.cstat.setInt(7, Integer.parseInt(tfPDiscount.getText()));
                connect.cstat.setBigDecimal(8, parseRp(tfMAmount.getText(),1));
                connect.cstat.setInt(9, 1);

                connect.cstat.execute();
                popup(popop_success, deskSuccess, "Discount Updated!!");
                loadData();
                dsc.getIdDiscount(tfID);
                btn_add.setVisible(true);
                btn_upd2.setVisible(false);
                clear();
            } catch (SQLException e) {
                alertError("Error :" + e.getMessage());
            }
        }
    }

    @Override
    public void deleteData(int id) {
        if (alertConfirm("Are you sure you want to delete data?")) {
            try {
                connect.cstat = connect.conn.prepareCall("{call DeletePromoDiskonById(?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                popup(popop_success, deskSuccess, "Discount Deleted!!");
            } catch (SQLException e) {
                alertError("Error :" + e.getMessage());
            }
        }
    }

    @Override
    public void detailData(int id) {
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM PromoDiskon WHERE id_promo = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                dtName.setText(connect.result.getString("NamaPromo"));
                dtDescription.setText(connect.result.getString("Deskripsi"));
                dtStart.setText(connect.result.getString("TanggalMulai"));
                dtEnd.setText(connect.result.getString("TanggalAkhir"));
                dtPercentage.setText(connect.result.getString("Persentase_Diskon"));
                BigDecimal syaratMinPembelian = new BigDecimal(connect.result.getString("SyaratMinPembelian"));
                dtAmount.setText(formatRp(syaratMinPembelian.setScale(2, BigDecimal.ROUND_HALF_UP)));
                dtMember.setText(royal.getNameCategoryMember(connect.result.getInt("id_jenis_member")));
            }
            dtID.setText(String.format("DSC%03d", id));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
    }

    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }

    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }

    public void setBtn(int id) {
        btn_add.setVisible(false);
        btn_upd2.setVisible(true);
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM PromoDiskon WHERE id_promo = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                tfName.setText(connect.result.getString("NamaPromo"));
                taDeskripsi.setText(connect.result.getString("Deskripsi"));
                ObservableList<DisplayedItem> buffer = cbMember.getItems();
                for (DisplayedItem test : buffer) {
                    if (test.getActualValue().equals(connect.result.getString("id_jenis_member"))) {
                        cbMember.setValue(test);
                        break;
                    }
                }

                java.sql.Date sqlDateS = connect.result.getDate("TanggalMulai");
                StartDiscount.setValue(sqlDateS.toLocalDate());

                java.sql.Date sqlDateE = connect.result.getDate("TanggalAkhir");
                EndDiscount.setValue(sqlDateE.toLocalDate());

                tfPDiscount.setText(connect.result.getString("Persentase_Diskon"));
                BigDecimal syaratMinPembelian = new BigDecimal(connect.result.getString("SyaratMinPembelian"));
                tfMAmount.setText(formatRp(syaratMinPembelian.setScale(2, BigDecimal.ROUND_HALF_UP)));
                dtMember.setText(royal.getNameCategoryMember(id));
            }
            tfID.setText(String.format("DSC%03d", id));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
    }

    public void loadData() {
        deleteList(card_container);
        List<Discount> discountList = dsc.getDiscount(null, null, null);
        loadCard(discountList);
    }

    public void loadDataSearch() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        List<Discount> discountList = dsc.getDiscount((String) cbFilterType.getValue(), tfSearch.getText(), (String) cbFilterDiscount.getValue());
        if(discountList.size() == 0){
            popup(popop_warning, deskWarning, "No Discount Found!!");
        }else{
            loadCard(discountList);
        }
    }

    public void loadCard(List<Discount> discountList) {
        for (Discount discount : discountList) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/DiscountCard.fxml"));
                    Pane newCard = loader.load();
                    DiscountCard controller = loader.getController();
                    controller.dicountCard(discount.getIdDiscount(), discount.getName(), discount.getIdMember());
                    controller.setController(DiscountC.this);
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void clear() {
        dsc.getIdDiscount(tfID);
        tfName.setText("");
        cbMember.setValue(null);
        cbMember.setPromptText("Choose");
        StartDiscount.setValue(null);
        EndDiscount.setValue(null);
        tfMAmount.clear();
        tfPDiscount.clear();
        taDeskripsi.clear();
        btn_add.setVisible(true);
        btn_upd2.setVisible(false);
    }

    public void showFilter() {
        if (vb_filter.isVisible()) {
            vb_filter.setVisible(false);
        } else {
            vb_filter.setVisible(true);
        }
    }

    public void clearFilter() {
        cbFilterType.setValue(null);
        cbFilterDiscount.setValue(null);
    }
}
