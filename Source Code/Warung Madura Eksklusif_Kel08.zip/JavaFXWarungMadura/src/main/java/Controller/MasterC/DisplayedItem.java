package Controller.MasterC;

public class DisplayedItem {
    private String displayedValue;
    private String actualValue;

    public DisplayedItem(String displayedValue, String actualValue) {
        this.displayedValue = displayedValue;
        this.actualValue = actualValue;
    }

    public String getDisplayedValue() {
        return displayedValue;
    }

    public String getActualValue() {
        return actualValue;
    }

    @Override
    public String toString() {
        return displayedValue;
    }
}
