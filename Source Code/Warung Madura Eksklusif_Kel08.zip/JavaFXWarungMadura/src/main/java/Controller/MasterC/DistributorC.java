
package Controller.MasterC;

import Connection.DBConnect;
import Controller.Component.SupplierCard;
import Master.Supplier;
import SuperClassInterface.CRUD;
import SuperClassInterface.Controller;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.util.Duration;

import javax.swing.*;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DistributorC extends Controller implements CRUD {
    TranslateTransition detail_card = new TranslateTransition();
    @FXML
    VBox card_container, vbkiri, ap_kanan,  vb_filter;
    @FXML
    GridPane vbform;
    @FXML
    HBox main, hb_add;
    @FXML
    Pane popop_success, popop_warning, popop_error;
    @FXML
    Button btn_add, btn_upd2;
    @FXML
    TextField tfID, tfName, tfEmail, tfTelp, dtID, dtName, tfSearch, dtEmail, dtTelp;
    @FXML
    TextArea taAddress, dtAddress;
    @FXML
    AnchorPane detail_container, ap_atas, ap_kiri, main_content;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    @FXML
    ScrollPane sp_view;
    Supplier sp = new Supplier();
    DBConnect connect = new DBConnect();
    @FXML
    ComboBox<String> cbFilterType;
    private ExecutorService executorService = Executors.newFixedThreadPool(1);

    private int idSpr;
    public int getIdSpr() {
        return idSpr;
    }
    public void setIdSpr(int idSpr) {
        this.idSpr = idSpr;
    }

    public void initialize() {
        loadData();
        sp.getIdSupplier(tfID);
        tfName.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        tfTelp.addEventFilter(KeyEvent.KEY_TYPED, keyEvent -> {
            String character = keyEvent.getCharacter();
            if (!character.matches("[0-9]") && !character.equals("\b") && !character.equals("\n") ||tfTelp.getText().length() >= 13) {
                keyEvent.consume();
            }
        });
        cbFilterType.getItems().addAll("ID","Name");
    }
    @Override
    public void insertData() {
        if (tfName.getText().isEmpty()||taAddress.getText().isEmpty()||tfTelp.getText().isEmpty()||tfEmail.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        }else if(!tfEmail.getText().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")){
            popup(popop_warning,deskWarning,"Email not valid!!");
            tfEmail.setText("");
        }else if(tfTelp.getText().length() <= 10){
            popup(popop_warning,deskWarning,"Phone length must more than 10!!");
            tfTelp.setText("");
        }else if(trueUser(tfTelp.getText(),Integer.parseInt(tfID.getText().substring(3)))>0){
            popup(popop_warning,deskWarning,"Phone Already Exist!!");
            tfTelp.setText("");
        }else {
            connect.cstat = null;
            try {
                connect.cstat = connect.conn.prepareCall("{call SpInsertSupplier(?,?,?,?,?)}");
                connect.cstat.setString(1, tfName.getText());
                connect.cstat.setString(2, taAddress.getText());
                connect.cstat.setString(3, tfTelp.getText());
                connect.cstat.setString(4, tfEmail.getText());
                connect.cstat.setInt(5, 1);
                connect.cstat.execute();
                connect.cstat.close();
                popup(popop_success, deskSuccess, "Distributor Inserted!!");
                loadData();
                clear();
                sp.getIdSupplier(tfID);
            } catch (SQLException e) {
                popup(popop_error, deskError, "Error:" + e.getMessage());
            }
        }
    }
    @Override
    public void detailData(int id) {
        int ID = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Supplier WHERE id_supplier = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_supplier");
                dtName.setText(connect.result.getString("NamaSupplier"));
                dtAddress.setText(connect.result.getString("Alamat"));
                dtTelp.setText(connect.result.getString("NoTelepon"));
                dtEmail.setText(connect.result.getString("Email"));
            }
            dtID.setText(String.format("SPR%02d", ID));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            popup(popop_error, deskError, "Error:" + e.getMessage());
        }
    }
    @Override
    public void updateData() {
        if (tfName.getText().isEmpty()||taAddress.getText().isEmpty()||tfTelp.getText().isEmpty()||tfEmail.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        }else if(!tfEmail.getText().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")){
            popup(popop_warning,deskWarning,"Email not valid!!");
            tfEmail.setText("");
        }else if(tfTelp.getText().length() <= 10){
            popup(popop_warning,deskWarning,"Phone length must more than 10!!");
            tfTelp.setText("");
        }else if(trueUser(tfTelp.getText(),Integer.parseInt(tfID.getText().substring(3)))>0){
            popup(popop_warning,deskWarning,"Phone Already Exist!!");
            tfTelp.setText("");
        } else {
            try {
                connect.cstat = connect.conn.prepareCall("{call SpUpdateSupplier(?,?,?,?,?,?)}");
                connect.cstat.setInt(1, getIdSpr());
                connect.cstat.setString(2, tfName.getText());
                connect.cstat.setString(3, taAddress.getText());
                connect.cstat.setString(4, tfTelp.getText());
                connect.cstat.setString(5, tfEmail.getText());
                connect.cstat.setInt(6, 1);
                connect.cstat.executeUpdate();
                connect.cstat.close();
                loadData();
                btn_add.setVisible(true);
                btn_upd2.setVisible(false);
                clear();
                popup(popop_success, deskSuccess, "Distributor Updated!!");
            } catch (SQLException e) {
                popup(popop_error, deskError, "Error:" + e.getMessage());
            }
        }
    }
    @Override
    public void deleteData(int id) {
        if (alertConfirm("Are you sure you want to delete data?")) {
            try {
                connect.cstat = connect.conn.prepareCall("{call DeleteSupplierById(?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                popup(popop_success, deskSuccess, "Distributor Deleted!!");
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }

    public void loadData() {
        deleteList(card_container);
        List<Supplier> suppliers = sp.getSupplier(null,null);
        loadCard(suppliers);
    }

    public void loadDataSearch() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        List<Supplier> suppliers = sp.getSupplier(cbFilterType.getValue(), tfSearch.getText());
        if (suppliers.size() == 0) {
            popup(popop_warning, deskWarning, "No Distributor Found!!");
        }else{
            loadCard(suppliers);
        }
    }

    public void loadCard(List<Supplier> suppliers) {
        for (Supplier spr : suppliers) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/DistributorCard.fxml"));
                    Pane newCard = loader.load();
                    SupplierCard controller = loader.getController();
                    controller.supplierDataCard(spr.getIdSupplier(), spr.getName(), spr.getAddress(), spr.getPhone(), spr.getEmail());
                    controller.setController(DistributorC.this);
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void clear(){
        tfName.setText("");
        tfTelp.setText("");
        tfEmail.setText("");
        taAddress.setText("");
        sp.getIdSupplier(tfID);
        btn_add.setVisible(true);
        btn_upd2.setVisible(false);
    }

    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }

    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }

    public void setBtn(int id) {
        btn_add.setVisible(false);
        btn_upd2.setVisible(true);
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Supplier WHERE id_supplier = " + id;
            tfID.setText(String.format("SPR%02d", id));
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                tfName.setText(connect.result.getString("NamaSupplier"));
                taAddress.setText(connect.result.getString("Alamat"));
                tfTelp.setText(connect.result.getString("NoTelepon"));
                tfEmail.setText(connect.result.getString("Email"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            popup(popop_error, deskError, "Error:" + e.getMessage());
        }
    }

    public void showFilter(){
        if(vb_filter.isVisible()){
            vb_filter.setVisible(false);
        }else{
            vb_filter.setVisible(true);
        }
    }

    public void clearFilter(){
        cbFilterType.setValue(null);
    }
    public int trueUser(String phone, int memberId){
        try {
            String query = "SELECT COUNT(*) FROM Supplier WHERE NoTelepon = ? AND id_supplier <> ?";
            connect.pstat = connect.conn.prepareStatement(query);
            connect.pstat.setString(1, phone);
            connect.pstat.setInt(2, memberId);

            connect.result = connect.pstat.executeQuery();
            if (connect.result.next()) {
                return connect.result.getInt(1);
            }
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return 0;
    }
}
