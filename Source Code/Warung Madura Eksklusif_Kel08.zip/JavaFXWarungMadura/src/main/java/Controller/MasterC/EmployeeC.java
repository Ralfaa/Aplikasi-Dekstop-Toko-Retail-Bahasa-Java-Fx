package Controller.MasterC;

import Connection.DBConnect;
import Controller.Component.EmployeeCard;
import Master.*;
import SuperClassInterface.*;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.util.Duration;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.*;


public class EmployeeC extends Controller implements CRUD {
    @FXML
    VBox card_container, ap_kanan, vbkiri, vb_filter;
    @FXML
    ImageView imageview, dtImage;
    @FXML
    Button btn_add, btn_upd2;
    @FXML
    HBox main, hb_add;
    @FXML
    GridPane vbform;
    @FXML
    AnchorPane detail_container, ap_atas, ap_kiri, main_content;
    @FXML
    TextField tfSearch, tfID, tfUserName, tfName, tfEmail, tfPhone, dtID, dtUsername, dtName, dtEmail, dtPhone, dtGender, dtPosition, dtPassword;
    @FXML
    PasswordField tfPassword;
    @FXML
    TextArea taAddress, dtAddress;
    @FXML
    ComboBox cbPosition, cbGender, cbFilterType, cbFilterPosition;
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    EmployeeCard controller;
    Employee emp = new Employee();
    Position pst = new Position();
    @FXML
    ScrollPane sp_view;
    TranslateTransition detail_card = new TranslateTransition();
    private ExecutorService executorService = Executors.newFixedThreadPool(1);

    DBConnect connect = new DBConnect();
    FileChooser fileChooser = new FileChooser();
    Stage stage = new Stage();
    private int idEmp;
    private String currentPw;

    public void setIdEmp(int idEmp) {
        this.idEmp = idEmp;
    }

    public int getIdEmp() {
        return idEmp;
    }

    public void initialize() {
        loadData();
        pst.getNamePosition(cbPosition);
        pst.getNamePosition(cbFilterPosition);
        emp.getIdEmployee(tfID);
        tfName.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        tfPhone.addEventFilter(KeyEvent.KEY_TYPED, keyEvent -> {
            String character = keyEvent.getCharacter();
            if (!character.matches("[0-9]") && !character.equals("\b") && !character.equals("\n") || tfPhone.getText().length() >= 13) {
                keyEvent.consume();
            }
        });
        cbGender.getItems().addAll("Male", "Female");
        cbFilterType.getItems().addAll("ID", "Name");
    }

    public void insertData() {
        int isSuccess;
        if (tfID.getText().isEmpty() || tfName.getText().isEmpty() || tfUserName.getText().isEmpty() || tfEmail.getText().isEmpty() || tfPhone.getText().isEmpty() || tfPassword.getText().isEmpty() || taAddress.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        }else if (!tfEmail.getText().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
            popup(popop_warning, deskWarning, "Email not valid!!");
            tfEmail.setText("");
        }else if (tfPhone.getText().length() <= 10) {
            popup(popop_warning, deskWarning, "Phone length must be more than 10!!");
            tfPhone.setText("");
        } else if (trueUser(tfPhone.getText(), Integer.parseInt(tfID.getText().substring(3)))>0) {
            popup(popop_warning, deskWarning, "Phone already exists!");
            tfPhone.setText("");
        } else if (!tfPassword.getText().matches(".*[a-z].*") || !tfPassword.getText().matches(".*[A-Z].*")) {
            popup(popop_warning, deskWarning, "Pass need lower upper case!!");
            tfPassword.setText("");
        } else if (tfPassword.getText().length() < 6) {
            popup(popop_warning, deskWarning, "Pass length must be more than 5!!");
            tfPassword.setText("");
        } else if (tfPassword.getText().length() > 10) {
            popup(popop_warning, deskWarning, "Pass length must be less than 10!!");
            tfPassword.setText("");
        } else if (!tfPassword.getText().matches(".*[0-9].*")) {
            popup(popop_warning, deskWarning, "Pass need number!!");
            tfPassword.setText("");
        } else if (trueEmail(tfEmail.getText(), Integer.parseInt(tfID.getText().substring(3)))>0) {
            popup(popop_warning, deskWarning, "Email Already Exist!!");
            tfUserName.setText("");
        } else {
            connect.cstat = null;
            int id = pst.getIdPosition(cbPosition.getValue().toString());
            byte[] image = null;

            try {
                if (imageview.getImage() != null) {
                    String pathImage = imageview.getImage().getUrl();
                    image = Files.readAllBytes(Paths.get(new URI(pathImage)));
                }
                connect.cstat = connect.conn.prepareCall("{call SpInsertKaryawan(?,?,?,?,?,?,?,?,?,?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.setString(2, tfName.getText());
                connect.cstat.setString(3, tfUserName.getText());
                connect.cstat.setString(4, tfPassword.getText());
                connect.cstat.setString(5, taAddress.getText());
                connect.cstat.setString(6, tfPhone.getText());
                connect.cstat.setString(7, tfEmail.getText());
                connect.cstat.setString(8, cbGender.getValue().toString());
                connect.cstat.setBytes(9, image);
                connect.cstat.setInt(10, 1);
                isSuccess = connect.cstat.executeUpdate();
                if (isSuccess==1) {
                    popup(popop_success, deskSuccess, "Employee Inserted!!");
                    loadData();
                    clear();
                    emp.getIdEmployee(tfID);
                } else {
                    popup(popop_warning, deskWarning, "Username Already Exist!!");
                    tfUserName.setText("");
                    return;
                }
                connect.cstat.close();
            } catch (SQLException | IOException | URISyntaxException e) {
                alertError("Error :" + e.getMessage());
            }
        }
    }

    @Override
    public void updateData() {
        int isSucces;
        int id = pst.getIdPosition(cbPosition.getValue().toString());
        if (tfID.getText().isEmpty() || tfName.getText().isEmpty() || tfUserName.getText().isEmpty() || tfEmail.getText().isEmpty() || tfPhone.getText().isEmpty() || tfPassword.getText().isEmpty() || taAddress.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        }else if (!tfEmail.getText().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
            popup(popop_warning, deskWarning, "Email not valid!!");
            tfEmail.setText("");
        }else if (tfPhone.getText().length() <= 10) {
            popup(popop_warning, deskWarning, "Phone length must be more than 10!!");
            tfPhone.setText("");
        } else if (trueUser(tfPhone.getText(), Integer.parseInt(tfID.getText().substring(3)))>0) {
            popup(popop_warning, deskWarning, "Phone already exists!");
            tfPhone.setText("");
        } else if (!tfPassword.getText().matches(".*[a-z].*") || !tfPassword.getText().matches(".*[A-Z].*")) {
            popup(popop_warning, deskWarning, "Pass need lower upper case!!");
            tfPassword.setText("");
        } else if (tfPassword.getText().length() < 6) {
            popup(popop_warning, deskWarning, "Pass length must be more than 5!!");
            tfPassword.setText("");
        } else if (tfPassword.getText().length() > 10) {
            popup(popop_warning, deskWarning, "Pass length must be less than 10!!");
            tfPassword.setText("");
        } else if (!tfPassword.getText().matches(".*[0-9].*")) {
            popup(popop_warning, deskWarning, "Pass need number!!");
            tfPassword.setText("");
        } else if (trueUsername(tfUserName.getText(), Integer.parseInt(tfID.getText().substring(3)))>0) {
            popup(popop_warning, deskWarning, "Username Already Exist!!");
            tfUserName.setText("");
        } else if (trueEmail(tfEmail.getText(), Integer.parseInt(tfID.getText().substring(3)))>0) {
            popup(popop_warning, deskWarning, "Email Already Exist!!");
            tfUserName.setText("");
        }else {
            try {
                byte[] image = null;
                boolean changeImg = false;
                Image img = imageview.getImage();

                if (img != null) {
                    String pathImage = img.getUrl();
                    if (pathImage != null && !pathImage.isEmpty()) {
                        try {
                            image = Files.readAllBytes(Path.of(new URI(pathImage)));
                            changeImg = true;
                        } catch (IOException | URISyntaxException e) {
                            alertError("Error :"+e.getMessage());
                            return;
                        }
                    }
                }
                if (!changeImg) {
                    image = emp.getImageEmpFromDatabase(idEmp);
                }
                connect.cstat = connect.conn.prepareCall("{call SpUpdateKaryawan(?,?,?,?,?,?,?,?,?,?,?)}");
                connect.cstat.setInt(1, getIdEmp());
                connect.cstat.setInt(2, id);
                connect.cstat.setString(3, tfName.getText());
                connect.cstat.setString(4, tfUserName.getText());
                connect.cstat.setString(5, tfPassword.getText().equals(currentPw) ? null : tfPassword.getText());
                connect.cstat.setString(6, taAddress.getText());
                connect.cstat.setString(7, tfPhone.getText());
                connect.cstat.setString(8, tfEmail.getText());
                connect.cstat.setString(9, cbGender.getValue().toString());
                connect.cstat.setBytes(10, image);
                connect.cstat.setInt(11, 1);
                    popup(popop_success, deskSuccess, "Employee Updated!!");
                    loadData();
                    btn_add.setVisible(true);
                    btn_upd2.setVisible(false);
                    clear();
                connect.cstat.close();
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }

    @Override
    public void deleteData(int id) {
        if (alertConfirm("Are you sure you want to delete data?")) {
            try {
                connect.cstat = connect.conn.prepareCall("{call DeleteKaryawanById(?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                popup(popop_success, deskSuccess, "Employee Deleted!!");
            } catch (SQLException e) {
                popup(popop_error, deskError, "Error:" + e.getMessage());
            }
        }
    }

    @Override
    public void detailData(int id) {
        try {
            int idPosition = 0, ID = 0, status = 0;
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Karyawan WHERE id_karyawan = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_karyawan");
                idPosition = connect.result.getInt("id_jabatan");
                dtName.setText(connect.result.getString("NamaKaryawan"));
                dtUsername.setText(connect.result.getString("Username"));
                dtEmail.setText(connect.result.getString("Email"));
                dtPassword.setText(connect.result.getString("Password"));
                dtAddress.setText(connect.result.getString("Alamat"));
                dtPhone.setText(connect.result.getString("NoTelepon"));
                dtGender.setText(connect.result.getString("JenisKelamin"));
                byte[] img = connect.result.getBytes("Picture");
                if (img != null) {
                    InputStream input = new ByteArrayInputStream(img);
                    Image image = new Image(input);
                    dtImage.setImage(image);
                } else {
                    dtImage.setImage(null);
                }
            }
            dtPosition.setText(pst.getNamePosition(idPosition));
            dtID.setText(String.format("EMP%03d", ID));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }

    public void importImage() {
        handleImport(stage, fileChooser);
    }

    @Override
    public void handleImport(Stage stage, FileChooser fileChooser) {
        long maxSize = 1 * 1024 * 1024;
        super.handleImport(stage, fileChooser);
        File selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null) {
            try {
                long imgSize = Files.size(selectedFile.toPath());
                if (imgSize > maxSize) {
                    popup(popop_warning, deskWarning, "Max picture size 1MB!!");
                } else {
                    Image image = new Image(selectedFile.toURI().toString());
                    popup(popop_success, deskSuccess, "Picture inserted succesfully!!");
                    imageview.setImage(image);
                }
            } catch (IOException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }

    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }

    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }

    public void setBtn(int id) {
        btn_add.setVisible(false);
        btn_upd2.setVisible(true);
        int idPosition = 0, ID = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Karyawan WHERE id_karyawan = " + id;
            tfID.setText(String.format("EMP%03d", id));
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_karyawan");
                tfUserName.setText(connect.result.getString("Username"));
                tfName.setText(connect.result.getString("NamaKaryawan"));
                cbGender.setValue(connect.result.getString("JenisKelamin"));
                tfEmail.setText(connect.result.getString("Email"));
                tfPhone.setText(connect.result.getString("NoTelepon"));
                tfPassword.setText(connect.result.getString("Password"));
                currentPw = connect.result.getString("Password");
                taAddress.setText(connect.result.getString("Alamat"));
                byte[] img = connect.result.getBytes("Picture");
                if (img != null) {
                    InputStream input = new ByteArrayInputStream(img);
                    Image image = new Image(input);
                    imageview.setImage(image);
                } else {
                    imageview.setImage(null);
                }
                idPosition = connect.result.getInt("id_jabatan");
            }
            tfID.setText(String.format("EMP%03d", ID));
            cbPosition.setValue(pst.getNamePosition(idPosition));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }

    public void loadData() {
        deleteList(card_container);
        List<Employee> employees = emp.getEmployee(null,null,null);
        loadCard(employees);
    }
    public void loadCard(List<Employee> employees) {
        for (Employee emp : employees) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/EmployeeCard.fxml"));
                    Pane newCard = loader.load();
                    controller = loader.getController();
                    controller.employeeDataCard(emp.getIdEmployee(), emp.getName(), emp.getIdJabatan());
                    controller.setController(EmployeeC.this);
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void loadDataSearch() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        List<Employee> employees = emp.getEmployee((String) cbFilterType.getValue(), tfSearch.getText(), (String) cbFilterPosition.getValue());
        if(employees.size() == 0){
            popup(popop_warning, deskWarning, "No Employee Found!!");
        }else{
            loadCard(employees);
        }
    }

    public void clear() {
        emp.getIdEmployee(tfID);
        tfName.setText("");
        tfUserName.setText("");
        tfPassword.setText("");
        taAddress.setText("");
        tfPhone.setText("");
        tfEmail.setText("");
        cbPosition.setValue("Choose");
        imageview.setImage(null);
        btn_add.setVisible(true);
        btn_upd2.setVisible(false);
    }

    public void showFilter() {
        if (vb_filter.isVisible()) {
            vb_filter.setVisible(false);
        } else {
            vb_filter.setVisible(true);
        }
    }

    public void clearFilter() {
        cbFilterType.setValue(null);
        cbFilterPosition.setValue(null);
    }
    public int trueUser(String phone, int memberId){
        try {
            String query = "SELECT COUNT(*) FROM Karyawan WHERE NoTelepon = ? AND id_karyawan <> ?";
            connect.pstat = connect.conn.prepareStatement(query);
            connect.pstat.setString(1, phone);
            connect.pstat.setInt(2, memberId);

            connect.result = connect.pstat.executeQuery();
            if (connect.result.next()) {
                return connect.result.getInt(1);
            }
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return 0;
    }
    public int trueUsername(String user, int Id){
        try {
            String query = "SELECT COUNT(*) FROM Karyawan WHERE Username = ? AND id_karyawan <> ?";
            connect.pstat = connect.conn.prepareStatement(query);
            connect.pstat.setString(1, user);
            connect.pstat.setInt(2, Id);

            connect.result = connect.pstat.executeQuery();
            if (connect.result.next()) {
                return connect.result.getInt(1);
            }
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return 0;
    }
    public int trueEmail(String user, int Id){
        try {
            String query = "SELECT COUNT(*) FROM Karyawan WHERE Email = ? AND id_karyawan <> ?";
            connect.pstat = connect.conn.prepareStatement(query);
            connect.pstat.setString(1, user);
            connect.pstat.setInt(2, Id);

            connect.result = connect.pstat.executeQuery();
            if (connect.result.next()) {
                return connect.result.getInt(1);
            }
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return 0;
    }
}
