package Controller.MasterC;

import Connection.DBConnect;
import Controller.Component.MemberCard;
import Master.Member;
import Master.MemberRoyalty;
import SuperClassInterface.CRUD;
import SuperClassInterface.Controller;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.util.Duration;

import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MemberC extends Controller implements CRUD {
    @FXML
    VBox card_container, ap_kanan, vbkiri, vb_filter;
    @FXML
    Button btn_add, btn_upd2;
    @FXML
    HBox main, hb_add;
    @FXML
    GridPane vbform;
    @FXML
    AnchorPane detail_container, ap_atas, ap_kiri,  main_content;
    @FXML
    TextField tfSearch, tfID, tfName, tfEmail, tfPhone, dtID, dtEmail, tfPoint, dtName, dtPhone, dtPoint, dtRoyalty;
    @FXML
    TextArea taAddress, dtAddress;
    @FXML
    ComboBox cbFilterType, cbFilterMember;
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    Member mbr = new Member();
    MemberRoyalty royal = new MemberRoyalty();
    @FXML
    ScrollPane sp_view;
    TranslateTransition detail_card = new TranslateTransition();
    private ExecutorService executorService = Executors.newFixedThreadPool(1);
    DBConnect connect = new DBConnect();
    private int idMember;
    public void setIdMember(int idMember) {
        this.idMember = idMember;
    }

    public void initialize() {
        loadData();
        mbr.MemberId(tfID);
        mbr.getNameMember(cbFilterMember);
        tfName.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        tfPhone.addEventFilter(KeyEvent.KEY_TYPED, keyEvent -> {
            String character = keyEvent.getCharacter();
            if (!character.matches("[0-9]") && !character.equals("\b") && !character.equals("\n") ||tfPhone.getText().length() >= 13) {
                keyEvent.consume();
            }
        });
        tfPoint.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
        cbFilterType.getItems().addAll("ID","Name","Point","Royalty");
    }
    @Override
    public void insertData() {
        if (tfName.getText().isEmpty() || tfEmail.getText().isEmpty() || tfPhone.getText().isEmpty() || taAddress.getText().isEmpty()) {
            popup(popop_warning,deskWarning,"Uncompleted Data!!");
        }else if(!tfEmail.getText().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")){
            popup(popop_warning,deskWarning,"Email Not Valid!!");
            tfEmail.setText("");
        }else if(tfPhone.getText().length() <= 10){
            popup(popop_warning,deskWarning,"Phone length must more than 10!!");
            tfPhone.setText("");
        }else if(trueUser(tfPhone.getText(),Integer.parseInt(tfID.getText().substring(3))) >0){
            popup(popop_warning,deskWarning,"Phone Already Exists!!");
            tfPhone.setText("");
        }else{
            connect.cstat = null;
            try {
                connect.cstat = connect.conn.prepareCall("{call SpInsertMember(?,?,?,?,?,?,?)}");
                connect.cstat.setNull(1, Types.NULL);
                connect.cstat.setString(2, tfName.getText());
                connect.cstat.setString(3, taAddress.getText());
                connect.cstat.setString(4, tfPhone.getText());
                connect.cstat.setString(5, tfEmail.getText());
                connect.cstat.setInt(6, 0);
                connect.cstat.setInt(7, 1);
                connect.cstat.execute();
                connect.cstat.close();
                popup(popop_success,deskSuccess,"Membership Inserted!!");
                loadData();
                clear();
                mbr.MemberId(tfID);
            } catch (SQLException e) {
                popup(popop_error, deskError,"Error:"+e.getMessage());
            }
        }
    }
    @Override
    public void updateData() {
        if (tfName.getText().isEmpty() || tfEmail.getText().isEmpty() || tfPhone.getText().isEmpty() || taAddress.getText().isEmpty()) {
            popup(popop_warning,deskWarning,"Uncompleted Data!!");
        }else if(!tfEmail.getText().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")){
            popup(popop_warning,deskWarning,"Email Not Valid!!");
            tfEmail.setText("");
        }else if(tfPhone.getText().length() <= 10){
            popup(popop_warning,deskWarning,"Phone length must more than 10!!");
            tfPhone.setText("");
        }else if(trueUser(tfPhone.getText(),Integer.parseInt(tfID.getText().substring(3))) >0){
            popup(popop_warning,deskWarning,"Phone Already Exists!!");
            tfPhone.setText("");
        }else{
            try {

                connect.cstat = connect.conn.prepareCall("{call SpUpdateMember(?,?,?,?,?,?,?)}");
                connect.cstat.setInt(1, idMember);
                connect.cstat.setString(2, tfName.getText());
                connect.cstat.setString(3, taAddress.getText());
                connect.cstat.setString(4, tfPhone.getText());
                connect.cstat.setString(5, tfEmail.getText());
                connect.cstat.setString(6, tfPoint.getText());
                connect.cstat.setInt(7, 1);
                connect.cstat.execute();
                connect.cstat.close();
                popup(popop_success,deskSuccess,"Membership Updated!!");
                loadData();
                btn_add.setVisible(true);
                btn_upd2.setVisible(false);
                clear();
                mbr.MemberId(tfID);
            } catch (SQLException e) {
                popup(popop_error, deskError,"Error:"+e.getMessage());
            }
        }
    }
    @Override
    public void deleteData(int id) {
        if (alertConfirm("Are you sure you want to delete data?")){
            try {
                connect.cstat = connect.conn.prepareCall("{call DeleteMemberById(?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                popup(popop_success,deskSuccess,"Membership Deleted!!");
            } catch (SQLException e) {
                popup(popop_error, deskError,"Error:"+e.getMessage());
            }
        }
    }
    @Override
    public void detailData(int id) {
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Member WHERE id_member = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                dtRoyalty.setText(royal.getNameCategoryMember(connect.result.getInt("id_jenis_member")));
                dtName.setText(connect.result.getString("Nama"));
                dtPoint.setText(connect.result.getString("Point"));
                dtAddress.setText(connect.result.getString("Alamat"));
                dtPhone.setText(connect.result.getString("NoTelepon"));
                dtEmail.setText(connect.result.getString("Email"));
            }
            dtID.setText(String.format("MBR%03d",id));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }
    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }
    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }
    public void setBtn(int id) {
        btn_add.setVisible(false);
        btn_upd2.setVisible(true);
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Member WHERE id_member = " + id ;
            tfID.setText(String.format("MBR%03d",id));
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                tfName.setText(connect.result.getString("Nama"));
                tfPoint.setText(connect.result.getString("Point"));
                tfEmail.setText(connect.result.getString("Email"));
                tfPhone.setText(connect.result.getString("NoTelepon"));
                taAddress.setText(connect.result.getString("Alamat"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }
    public void loadData() {
        deleteList(card_container);
        List<Member> members = mbr.getMember(null,null, null);
        loadCard(members);
    }

    public void loadDataSearch() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        List<Member> members = mbr.getMember((String) cbFilterType.getValue(),tfSearch.getText(),(String) cbFilterMember.getValue());
        if (members.size() == 0){
            popup(popop_warning,deskWarning,"No Membership Found!!");
        }else{
            loadCard(members);
        }
    }
    public void loadCard(List<Member> members){
        for (Member member : members) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/MemberCard.fxml"));
                    Pane newCard = loader.load();
                    MemberCard controller = loader.getController();
                    controller.memberDataCard(member.getId(), member.getName(), member.getIdJMember(),member.getPoint());
                    controller.setController(MemberC.this);
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void clear() {
        mbr.MemberId(tfID);
        tfName.setText("");
        tfPoint.setText("");
        taAddress.setText("");
        tfPhone.setText("");
        tfEmail.setText("");
        btn_add.setVisible(true);
        btn_upd2.setVisible(false);
    }
    public void showFilter(){
        if(vb_filter.isVisible()){
            vb_filter.setVisible(false);
        }else{
            vb_filter.setVisible(true);
        }
    }
    public void clearFilter(){
        cbFilterType.setValue(null);
        cbFilterMember.setValue(null);
    }
    public int trueUser(String phone, int memberId){
        try {
            String query = "SELECT COUNT(*) FROM Member WHERE NoTelepon = ? AND id_member <> ?";
            connect.pstat = connect.conn.prepareStatement(query);
            connect.pstat.setString(1, phone);
            connect.pstat.setInt(2, memberId);

            connect.result = connect.pstat.executeQuery();
            if (connect.result.next()) {
                return connect.result.getInt(1);
            }
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return 0;
    }
}
