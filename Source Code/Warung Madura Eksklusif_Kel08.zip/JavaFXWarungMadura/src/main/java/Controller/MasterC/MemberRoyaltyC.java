
package Controller.MasterC;

import Connection.DBConnect;
import Controller.Component.MemberRoyaltyCard;
import Master.MemberRoyalty;
import SuperClassInterface.*;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.util.Duration;
import javax.swing.*;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.*;

public class MemberRoyaltyC extends Controller implements CRUD {
    TranslateTransition detail_card = new TranslateTransition();
    @FXML
    VBox card_container, vbkiri, ap_kanan,  vb_filter;
    @FXML
    GridPane vbform;
    @FXML
    HBox main, hb_add;
    @FXML
    Pane popop_success, popop_warning, popop_error;
    @FXML
    Button btn_add, btn_upd2;
    @FXML
    TextField tfID, tfName,dtID, dtName,dtMinPoint, tfSearch,tfMinPoint;
    @FXML
    AnchorPane detail_container, ap_atas, ap_kiri, main_content;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    @FXML
    ScrollPane sp_view;
    MemberRoyalty royal = new MemberRoyalty();
    DBConnect connect = new DBConnect();
    private ExecutorService executorService = Executors.newFixedThreadPool(1);

    @FXML
    ComboBox<String>  cbFilterType;
    private int idRoyalty;
    public int getIdRoyalty() {
        return idRoyalty;
    }

    public void initialize() {
        loadData();
        royal.getIdRoyalty(tfID);
        tfName.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        tfMinPoint.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
        cbFilterType.getItems().addAll("ID","Name", "Min Point");
    }
    @Override
    public void insertData() {
        if (tfName.getText().isEmpty()||tfMinPoint.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        } else {
            connect.cstat = null;
            try {
                connect.cstat = connect.conn.prepareCall("{call SpInsertJenisMember(?,?,?)}");
                connect.cstat.setString(1, tfName.getText());
                connect.cstat.setString(2, tfMinPoint.getText());
                connect.cstat.setInt(3, 1);
                connect.cstat.execute();
                connect.cstat.close();
                popup(popop_success, deskSuccess, "Type Royalty Inserted!!");
                loadData();
                clear();
                royal.getIdRoyalty(tfID);
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }
    @Override
    public void detailData(int id) {
        int ID = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM JenisMember WHERE id_jenis_member = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_jenis_member");
                dtName.setText(connect.result.getString("Nama"));
                dtMinPoint.setText(connect.result.getString("MinPoint"));
            }
            dtID.setText(String.format("MRY%02d", ID));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }
    @Override
    public void updateData() {
        if (tfName.getText().isEmpty()||tfMinPoint.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        } else {
            try {
                connect.cstat = connect.conn.prepareCall("{call SpUpdateJenisMember(?,?,?,?)}");
                connect.cstat.setInt(1, getIdRoyalty());
                connect.cstat.setString(2, tfName.getText());
                connect.cstat.setString(3, tfMinPoint.getText());
                connect.cstat.setInt(4, 1);
                connect.cstat.executeUpdate();
                connect.cstat.close();
                loadData();
                btn_add.setVisible(true);
                btn_upd2.setVisible(false);
                clear();
                popup(popop_success, deskSuccess, "Type Royalty Updated!!");
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }
    @Override
    public void deleteData(int id) {
        if (alertConfirm("Are you sure you want to delete data?")) {
            try {
                connect.cstat = connect.conn.prepareCall("{call DeleteJenisMemberById(?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                popup(popop_success, deskSuccess, "Type Royalty Deleted!!");
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }
    public void setIdRoyalty(int idPst) {
        this.idRoyalty = idPst;
    }

    public void loadData() {
        deleteList(card_container);
        List<MemberRoyalty> royalty = royal.getMemberRoyalty(null,null);
        loadCard(royalty);
    }

    public void loadDataSearch() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        List<MemberRoyalty> royalties = royal.getMemberRoyalty(cbFilterType.getValue(), tfSearch.getText());
        if (royalties.size() == 0){
            popup(popop_warning, deskWarning, "No Type Royalty Found!!");
        }else{
            loadCard(royalties);
        }
    }

    public void loadCard(List<MemberRoyalty> royalties) {
        for (MemberRoyalty pos : royalties) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/MemberRoyaltyCard.fxml"));
                    Pane newCard = loader.load();
                    MemberRoyaltyCard controller = loader.getController();
                    controller.MemberRoyaltyDataCard (pos.getIdRoyalty(), pos.getName(), pos.getMinPoint());
                    controller.setController(MemberRoyaltyC.this);
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }
    public void clear(){
        tfName.clear();
        tfMinPoint.clear();
        btn_add.setVisible(true);
        btn_upd2.setVisible(false);
        royal.getIdRoyalty(tfID);
    }

    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }

    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }

    public void setBtn(int id) {
        btn_add.setVisible(false);
        btn_upd2.setVisible(true);
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM JenisMember WHERE id_jenis_member = " + id;
            tfID.setText(String.format("MRY%02d", id));
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                tfName.setText(connect.result.getString("Nama"));
                tfMinPoint.setText(connect.result.getString("MinPoint"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }

    public void showFilter(){
        if(vb_filter.isVisible()){
            vb_filter.setVisible(false);
        }else{
            vb_filter.setVisible(true);
        }
    }

    public void clearFilter(){
        cbFilterType.setValue(null);
    }
}