
package Controller.MasterC;

import Connection.DBConnect;
import Controller.Component.PositionCard;
import Master.Position;
import SuperClassInterface.*;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.util.Duration;

import javax.swing.*;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.*;

public class PositionC extends Controller implements CRUD {
    TranslateTransition detail_card = new TranslateTransition();
    @FXML
    VBox card_container, vbkiri, ap_kanan,  vb_filter;
    @FXML
    GridPane vbform;
    @FXML
    HBox main, hb_add;
    @FXML
    Pane popop_success, popop_warning, popop_error;
    @FXML
    Button btn_add, btn_upd2;
    @FXML
    TextField tfID, tfName;
    @FXML
    TextField dtAcces, dtID, dtName, tfSearch;
    @FXML
    AnchorPane detail_container, ap_atas, ap_kiri, main_content;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    @FXML
    ScrollPane sp_view;
    Position pst = new Position();
    DBConnect connect = new DBConnect();
    @FXML
    ComboBox<String> cbPosition, cbFilterType;
    private ExecutorService executorService = Executors.newFixedThreadPool(1); // Adjust the number of threads as needed

    private int idPst;
    public int getIdPst() {
        return idPst;
    }

    public void initialize() {
        loadData();
        pst.getIdPosition(tfID);
        tfName.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        cbPosition.getItems().addAll("Menu Admin", "Menu Cashier", "Menu Manager");
        cbFilterType.getItems().addAll("ID","Name", "Permission");
    }
    @Override
    public void insertData() {
        if (tfName.getText().isEmpty()||cbPosition.getValue()==null) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        } else {
            connect.cstat = null;
            try {
                connect.cstat = connect.conn.prepareCall("{call SpInsertKategoriJabatan(?,?,?)}");
                connect.cstat.setString(1, tfName.getText());
                connect.cstat.setString(2, cbPosition.getValue());
                connect.cstat.setInt(3, 1);
                connect.cstat.execute();
                connect.cstat.close();
                popup(popop_success, deskSuccess, "Position Inserted!!");
                loadData();
                clear();
                pst.getIdPosition(tfID);
            } catch (SQLException e) {
                popup(popop_error, deskError, "Error:" + e.getMessage());
            }
        }
    }
    @Override
    public void detailData(int id) {
        int ID = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriJabatan WHERE id_jabatan = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_jabatan");
                dtName.setText(connect.result.getString("NamaJabatan"));
                dtAcces.setText(connect.result.getString("Akses"));
            }
            dtID.setText(String.format("PST%02d", ID));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            popup(popop_error, deskError, "Error:" + e.getMessage());
        }
    }

    @Override
    public void updateData() {
        if (tfName.getText().isEmpty()||cbPosition.getValue()==null) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        } else {
            try {
                connect.cstat = connect.conn.prepareCall("{call SpUpdateKategoriJabatan(?,?,?,?)}");
                connect.cstat.setInt(1, getIdPst());
                connect.cstat.setString(2, tfName.getText());
                connect.cstat.setString(3, cbPosition.getValue());
                connect.cstat.setInt(4, 1);
                connect.cstat.executeUpdate();
                connect.cstat.close();
                loadData();
                btn_add.setVisible(true);
                btn_upd2.setVisible(false);
                clear();
                popup(popop_success, deskSuccess, "Position Updated!!");
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }
    @Override
    public void deleteData(int id) {
        if (alertConfirm("Are you sure you want to delete data?")) {
            try {
                connect.cstat = connect.conn.prepareCall("{call DeleteKategoriJabatanById(?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                popup(popop_success, deskSuccess, "Position Deleted!!");
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }

    public void setIdPst(int idPst) {
        this.idPst = idPst;
    }

    public void loadData() {
        deleteList(card_container);
        List<Position> positions = pst.getPosition(null, null);
        loadCard(positions);
    }

    public void loadDataSearch() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        List<Position> positions = pst.getPosition(cbFilterType.getValue(), tfSearch.getText());
        if (positions.size() == 0) {
            popup(popop_warning, deskWarning, "No Position Found!!");
        }else {
            loadCard(positions);
        }
    }
    public void loadCard(List<Position> positions) {
        for (Position pos : positions) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/PositionCard.fxml"));
                    Pane newCard = loader.load();
                    PositionCard controller = loader.getController();
                    controller.positionDataCard(pos.getIdPosition(), pos.getName(), pos.getAkses());
                    controller.setController(PositionC.this);
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void clear(){
        tfName.setText("");
        cbPosition.setValue(null);
        btn_add.setVisible(true);
        btn_upd2.setVisible(false);
        pst.getIdPosition(tfID);
    }

    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }

    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }

    public void setBtn(int id) {
        btn_add.setVisible(false);
        btn_upd2.setVisible(true);
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriJabatan WHERE id_jabatan = " + id;
            tfID.setText(String.format("PST%02d", id));
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                tfName.setText(connect.result.getString("NamaJabatan"));
                cbPosition.setValue(connect.result.getString("Akses"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }

    public void showFilter(){
        if(vb_filter.isVisible()){
            vb_filter.setVisible(false);
        }else{
            vb_filter.setVisible(true);
        }
    }

    public void clearFilter(){
        cbFilterType.setValue(null);
    }
}