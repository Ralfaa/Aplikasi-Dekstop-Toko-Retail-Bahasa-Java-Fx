package Controller.MasterC;

import Connection.DBConnect;
import Controller.Component.ProductCard;
import Master.*;
import SuperClassInterface.*;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.util.Duration;

import java.io.*;
import java.math.BigDecimal;
import java.net.*;
import java.nio.file.*;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.*;


public class ProductC extends Controller implements CRUD {
    @FXML
    VBox card_container, ap_kanan, vbkiri, vb_filter;
    @FXML
    ImageView imageview, dtImage;
    @FXML
    Button btn_add, btn_upd2;
    @FXML
    HBox main, hb_add;
    @FXML
    GridPane vbform;
    @FXML
    AnchorPane detail_container, ap_atas, ap_kiri,  main_content;
    @FXML
    TextField tfSearch, tfID, tfName, tfBuyPrice, tfStock, tfSellPrice, tfDiscount, dtID, dtName, dtCategories, dtSupplier, dtBuyPrice, dtSalePrice, dtStock, dtDiscount, dtStatus;
    @FXML
    ComboBox cbCategories, cbSupplier, cbFilterType, cbFilterSuppliers, cbFilterCategories;
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    @FXML
    ScrollPane sp_view;
    Product prd = new Product();
    ProductCategory pc = new ProductCategory();
    Supplier sp = new Supplier();
    TranslateTransition detail_card = new TranslateTransition();
    DBConnect connect = new DBConnect();
    FileChooser fileChooser = new FileChooser();
    Stage stage = new Stage();
    private ExecutorService executorService = Executors.newFixedThreadPool(1);

    private int idPrd;
    public void setIdPrd(int idPrd) {
        this.idPrd = idPrd;
    }
    public int getIdPrd(){
        return idPrd;
    }

    public void initialize() {
        loadData();
        pc.getNameCategories(cbCategories);
        pc.getNameCategories(cbFilterCategories);
        sp.getNameSupplier(cbSupplier);
        sp.getNameSupplier(cbFilterSuppliers);
        prd.getIdProduct(tfID);
        tfName.addEventFilter(KeyEvent.KEY_TYPED, e -> {
            String character = e.getCharacter();
            if (!character.matches("[0-9a-zA-Z ]")&& !character.equals("\b") && !character.equals("\n")) {
                e.consume();
            }
        });
        tfStock.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
        tfSellPrice.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
        tfDiscount.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
        tfBuyPrice.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
        cbFilterType.getItems().addAll("ID","Product Name","Supplier", "Category");
    }
    @Override
    public void insertData() {
        if (tfName.getText().isEmpty() || tfDiscount.getText().isEmpty() || tfBuyPrice.getText().isEmpty() || tfSellPrice.getText().isEmpty() || cbCategories.getValue().toString().isEmpty() || cbSupplier.getValue().toString().isEmpty()) {
            popup(popop_warning,deskWarning,"Uncompleted Data!!");
        } else {
            connect.cstat = null;

            int idSupplier = sp.getIdSupplier(cbSupplier.getValue().toString());
            int idCategory = pc.getIdCategories(cbCategories.getValue().toString());
            BigDecimal buyPrice = parseRp(tfBuyPrice.getText(),1);
            BigDecimal sellPrice = parseRp(tfSellPrice.getText(),1);

            int promoDiskon = 0;

            if(!tfDiscount.getText().isEmpty()) {
                promoDiskon = Integer.parseInt(tfDiscount.getText());
            }
            byte[] image = null;

            try {
                if (imageview.getImage() != null){
                    String pathImage = imageview.getImage().getUrl();
                    image = Files.readAllBytes(Paths.get(new URI(pathImage)));
                }

                connect.cstat = connect.conn.prepareCall("{call SpInsertProduk(?,?,?,?,?,?,?,?,?)}");
                connect.cstat.setInt(1, idCategory);
                connect.cstat.setInt(2, idSupplier);
                connect.cstat.setString(3, tfName.getText());
                connect.cstat.setBigDecimal(4, buyPrice);
                connect.cstat.setBigDecimal(5, sellPrice);
                connect.cstat.setInt(6, 0);
                connect.cstat.setInt(7, promoDiskon);
                connect.cstat.setBytes(8, image);
                connect.cstat.setInt(9, 1);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                clear();
                popup(popop_success,deskSuccess,"Product Inserted!!");
                prd.getIdProduct(tfID);
            } catch (SQLException | IOException | URISyntaxException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }
    @Override
    public void updateData() {
        int idSupplier = sp.getIdSupplier(cbSupplier.getValue().toString());
        int idCategory = pc.getIdCategories(cbCategories.getValue().toString());
        BigDecimal buyPrice = parseRp(tfBuyPrice.getText(),1);
        BigDecimal sellPrice = parseRp(tfSellPrice.getText(),1);
        int stock = Integer.parseInt(tfStock.getText());
        int promoDiskon = Integer.parseInt(tfDiscount.getText());

        if (tfName.getText().isEmpty() || tfDiscount.getText().isEmpty() || tfBuyPrice.getText().isEmpty() || tfSellPrice.getText().isEmpty() || cbCategories.getValue().toString().isEmpty() || cbSupplier.getValue().toString().isEmpty()) {
            popup(popop_warning,deskWarning,"Uncompleted Data!!");
        }else{
            try {
                byte[] image = null;
                boolean changeImg = false;
                Image img = imageview.getImage();

                if (img != null) {
                    String pathImage = img.getUrl();
                    if (pathImage != null && !pathImage.isEmpty()) {
                        try {
                            image = Files.readAllBytes(Path.of(new URI(pathImage)));
                            changeImg = true;
                        } catch (IOException | URISyntaxException e) {
                            alertError("Error :"+e.getMessage());
                            return;
                        }
                    }
                }
                if (!changeImg) {
                    image = prd.getImageFromDatabase(idPrd);
                }

                connect.cstat = connect.conn.prepareCall("{call SpUpdateProduk(?,?,?,?,?,?,?,?,?,?)}");
                connect.cstat.setInt(1, getIdPrd());
                connect.cstat.setInt(2, idCategory);
                connect.cstat.setInt(3, idSupplier);
                connect.cstat.setString(4, tfName.getText());
                connect.cstat.setBigDecimal(5, buyPrice);
                connect.cstat.setBigDecimal(6, sellPrice);
                connect.cstat.setInt(7, stock);
                connect.cstat.setInt(8, promoDiskon);
                connect.cstat.setBytes(9, image);
                connect.cstat.setInt(10, 1);
                connect.cstat.executeUpdate();
                connect.cstat.close();
                loadData();
                popup(popop_success,deskSuccess,"Product Updated!!");
                btn_add.setVisible(true);
                btn_upd2.setVisible(false);
                clear();
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }
    @Override
    public void deleteData(int id) {
        if(alertConfirm("Are you sure you want to delete product?")){
            try {
                connect.cstat = connect.conn.prepareCall("{call DeleteProdukById(?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                popup(popop_success,deskSuccess,"Product Deleted!!");
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }

    @Override
    public void detailData(int id) {
        int idCategory = 0;
        int idSupplier = 0;
        int ID = 0;
        int status = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Produk WHERE id_produk = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_produk");
                idCategory = connect.result.getInt("id_kategori");
                idSupplier = connect.result.getInt("id_supplier");
                dtName.setText(connect.result.getString("NamaProduk"));
                dtBuyPrice.setText(formatRp(connect.result.getBigDecimal("HargaBeli")));
                dtSalePrice.setText(formatRp(connect.result.getBigDecimal("HargaJual")));
                dtStock.setText(connect.result.getString("Stock"));
                dtDiscount.setText(connect.result.getString("PromoDiskon"));
                status = connect.result.getInt("Status");
                byte[] img = connect.result.getBytes("Picture");
                if (img != null) {
                    InputStream input = new ByteArrayInputStream(img);
                    Image image = new Image(input);
                    dtImage.setImage(image);
                }else{
                    dtImage.setImage(null);
                }
            }
            dtID.setText(String.format("PRD%03d",ID));

            String statusText;
            if (status == 1) {
                statusText = "Aktif";
            } else if (status == 0) {
                statusText = "Non Active";
            } else if (status == 2) {
                statusText = "Low Stock";
            } else if (status == 3) {
                statusText = "Critically Low Of Stock";
            } else if (status == 4) {
                statusText = "Out Of Stock";
            } else {
                statusText = "Unknown";
            }

            dtCategories.setText(pc.getNameCategories(idCategory));
            dtSupplier.setText(sp.getNameSupplier(idSupplier));
            dtStatus.setText(statusText);
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }
    public void importImage() {
        handleImport(stage, fileChooser);
    }

    @Override
    public void handleImport(Stage stage, FileChooser fileChooser) {
        long maxSize = 1 * 1024 * 1024;
        fileChooser.setTitle("Open Resource File");
        fileChooser.setInitialDirectory(new File("C:\\"));
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("PNG image", "*.png"),  new FileChooser.ExtensionFilter("All images", "*.jpg", "*.png"));
        File selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null) {
            try {
                long imgSize = Files.size(selectedFile.toPath());
                if (imgSize > maxSize) {
                    popup(popop_warning, deskWarning,"Max Picture Size 1 MB!");
                }else{
                    Image image = new Image(selectedFile.toURI().toString());
                    popup(popop_success, deskSuccess,"Picture Inserted Successfully!");
                    imageview.setImage(image);
                }
            } catch (IOException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }

    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }

    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }

    public void setBtn(int id) {
        btn_add.setVisible(false);
        btn_upd2.setVisible(true);
        int idCategory = 0, ID = 0, idSupplier = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Produk WHERE id_produk = " + id ;
            tfID.setText(String.format("PRD%03d",id));
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_produk");
                idCategory = connect.result.getInt("id_kategori");
                idSupplier = connect.result.getInt("id_supplier");
                tfName.setText(connect.result.getString("NamaProduk"));
                tfBuyPrice.setText(formatRp(connect.result.getBigDecimal("HargaBeli")));
                tfSellPrice.setText(formatRp(connect.result.getBigDecimal("HargaJual")));
                tfStock.setText(connect.result.getString("Stock"));
                tfDiscount.setText(connect.result.getString("PromoDiskon"));
                byte[] img = connect.result.getBytes("Picture");
                if (img != null){
                    InputStream input = new ByteArrayInputStream(img);
                    Image image = new Image(input);
                    imageview.setImage(image);
                }else {
                    imageview.setImage(null);
                }
            }
            tfID.setText(String.format("PRD%03d",ID));
            cbCategories.setValue(pc.getNameCategories(idCategory));
            cbSupplier.setValue(sp.getNameSupplier(idSupplier));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            popup(popop_error,deskError,"Error:"+e.getMessage());
        }
    }

    public void loadData() {
        deleteList(card_container);
        List<Product> products = prd.getProduct();
        loadCard(products);
    }

    public void loadDataSearch() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        List<Product> products = prd.getProduct(tfSearch.getText());
        if (products != null){
            loadCard(products);
        }else {
            popup(popop_warning, deskWarning,"Product not found!");
        }
    }
    public void loadDataFilter() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        Product product = new Product();
        List<Product> products = product.getProduct((String) cbFilterType.getValue(),(String) cbFilterCategories.getValue(),(String) cbFilterSuppliers.getValue());
        if (products != null){
            loadCard(products);
        }else {
            popup(popop_warning, deskWarning,"Product not found!");
        }
    }

    public void loadCard(List<Product> products){
        for (Product prd : products) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/ProductCard.fxml"));
                    Pane newCard = loader.load();
                    ProductCard controller = loader.getController();
                    controller.productDataCard(prd.getIdProduct(), prd.getIdSupplier(), prd.getIdProductCategory(), prd.getName());
                    controller.setController(ProductC.this);
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void clear() {
        prd.getIdProduct(tfID);
        tfName.setText("");
        tfBuyPrice.setText("");
        tfSellPrice.setText("");
        tfStock.setText("");
        tfDiscount.setText("");
        cbSupplier.setValue("Choose");
        cbCategories.setValue("Choose");
        imageview.setImage(null);
        btn_add.setVisible(true);
        btn_upd2.setVisible(false);
    }

    public void showFilter(){
        if(vb_filter.isVisible()){
            vb_filter.setVisible(false);
        }else{
            vb_filter.setVisible(true);
        }
    }
    public void clearFilter(){
        cbFilterType.setValue(null);
        cbFilterCategories.setValue(null);
        cbFilterSuppliers.setValue(null);
    }
}
