
package Controller.MasterC;

import Connection.DBConnect;
import Controller.Component.ProductCategoryCard;
import Master.ProductCategory;
import SuperClassInterface.CRUD;
import SuperClassInterface.Controller;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.util.Duration;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProductCategoryC extends Controller implements CRUD {
    TranslateTransition detail_card = new TranslateTransition();
    @FXML
    VBox card_container, vbkiri, ap_kanan,  vb_filter;
    @FXML
    GridPane vbform;
    @FXML
    HBox main, hb_add;
    @FXML
    Pane popop_success, popop_warning, popop_error;
    @FXML
    Button btn_add, btn_upd2;
    @FXML
    TextField tfID, tfName, tfUnit;
    @FXML
    TextField dtID, dtUnit, dtName, tfSearch;
    @FXML
    AnchorPane detail_container, ap_atas, ap_kiri, main_content;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    @FXML
    ScrollPane sp_view;
    ProductCategory pc = new ProductCategory();
    DBConnect connect = new DBConnect();
    private ExecutorService executorService = Executors.newFixedThreadPool(1); // Adjust the number of threads as needed

    @FXML
    ComboBox<String> cbFilterType;
    private int idPct;
    public int getIdPst() {
        return idPct;
    }
    public void setIdPct(int idPct) {
        this.idPct = idPct;
    }

    public void initialize() {
        loadData();
        pc.getIdProductCategory(tfID);
        tfName.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        tfUnit.addEventFilter(KeyEvent.KEY_TYPED, this::setAlphabet);
        cbFilterType.getItems().addAll("ID", "Name", "Satuan");
    }
    @Override
    public void insertData() {
        if (tfName.getText().isEmpty()||tfUnit.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "Uncompleted data!!");
        } else {
            connect.cstat = null;
            try {
                connect.cstat = connect.conn.prepareCall("{call SpInsertKategoriProduk(?,?,?)}");
                connect.cstat.setString(1, tfName.getText());
                connect.cstat.setString(2, tfUnit.getText());
                connect.cstat.setInt(3, 1);
                connect.cstat.execute();
                connect.cstat.close();
                popup(popop_success, deskSuccess, "Product Category Inserted!!");
                loadData();
                clear();
                pc.getIdProductCategory(tfID);
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }
    @Override
    public void detailData(int id) {
        int ID = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriProduk WHERE id_kategori = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_kategori");
                dtName.setText(connect.result.getString("NamaKategori"));
                dtUnit.setText(connect.result.getString("Satuan"));
            }
            dtID.setText(String.format("UNT%02d", ID));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }

    @Override
    public void updateData() {
        if (tfName.getText().isEmpty()||tfName.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "Uncompleted Data!!");
        } else {
            try {
                connect.cstat = connect.conn.prepareCall("{call SpUpdateKategoriProduk(?,?,?,?)}");
                connect.cstat.setInt(1, getIdPst());
                connect.cstat.setString(2, tfName.getText());
                connect.cstat.setString(3, tfUnit.getText());
                connect.cstat.setInt(4, 1);
                connect.cstat.executeUpdate();
                connect.cstat.close();
                loadData();
                btn_add.setVisible(true);
                btn_upd2.setVisible(false);
                clear();
                popup(popop_success, deskSuccess, "Product Category Updated!!");
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }
    @Override
    public void deleteData(int id) {
        if (alertConfirm("Are you sure you want to delete data?")) {
            try {
                connect.cstat = connect.conn.prepareCall("{call DeleteKategoriProdukById(?)}");
                connect.cstat.setInt(1, id);
                connect.cstat.execute();
                connect.cstat.close();
                loadData();
                popup(popop_success, deskSuccess, "Product Category Deleted!!");
            } catch (SQLException e) {
                alertError("Error :"+e.getMessage());
            }
        }
    }

    public void loadData() {
        deleteList(card_container);
        List<ProductCategory> productCategories = pc.getProductCategories(null,null);
        loadCard(productCategories);
    }

    public void loadDataSearch() {
        vb_filter.setVisible(false);
        deleteList(card_container);
        List<ProductCategory> productCategories = pc.getProductCategories(cbFilterType.getValue(), tfSearch.getText());
        if (productCategories.size()==0){
            popup(popop_warning, deskWarning, "No Product Category Found!!");
        }else{
            loadCard(productCategories);
        }
    }

    public void loadCard(List<ProductCategory> productCategories) {
        for (ProductCategory pct : productCategories) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/ProductCategoryCard.fxml"));
                    Pane newCard = loader.load();
                    ProductCategoryCard controller = loader.getController();
                    controller.productCategoryDataCard(pct.getIdProductCategory(), pct.getName(), pct.getUnit());
                    controller.setController(ProductCategoryC.this);
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void clear(){
        tfName.setText("");
        tfUnit.setText("");
        btn_add.setVisible(true);
        btn_upd2.setVisible(false);
        pc.getIdProductCategory(tfID);
    }

    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }

    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }

    public void setBtn(int id) {
        btn_add.setVisible(false);
        btn_upd2.setVisible(true);
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriProduk WHERE id_kategori = " + id;
            tfID.setText(String.format("UNT%02d", id));
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                tfName.setText(connect.result.getString("NamaKategori"));
                tfUnit.setText(connect.result.getString("Satuan"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }

    public void showFilter(){
        if(vb_filter.isVisible()){
            vb_filter.setVisible(false);
        }else{
            vb_filter.setVisible(true);
        }
    }

    public void clearFilter(){
        cbFilterType.setValue(null);
    }
}
