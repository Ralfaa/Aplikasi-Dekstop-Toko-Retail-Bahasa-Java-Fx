package Controller.Pages;

import Controller.LandingPage.LoginC;
import SuperClassInterface.Controller;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.util.Duration;
import java.io.IOException;
import java.util.logging.*;


public class AdminC extends Controller {
    @FXML
    AnchorPane barMaster, main, main_page;
    @FXML
    Button btn_dashboard, btn_profile, btn_order, data, data_close, btn_product, btn_product_category, btn_supplier, btn_employee, btn_position, btn_member, btn_discount, btn_typeloyalty, btn_logout;
    @FXML
    StackPane main_content;
    @FXML
    VBox menu;
    @FXML
    HBox hb_content;
    @FXML
    Pane pn_data;
    @FXML
    Label lbNamaKar;
    TranslateTransition barMenu = new TranslateTransition();
    Button lastClickedButton = new Button();
    public static int id;

    public void initialize() {
        menu();
        openMenu();
        closeMenu();
        defaultPage();
        menuNavigation();
        lbNamaKar.setText(lbNamaKar.getText().substring(0,9)+ LoginC.User.Name);
        main.setPrefHeight(getScreenHeight());
        menu.prefHeightProperty().bind(main.prefHeightProperty());
        menu.setPrefWidth(getScreenWidth()*0.2);
        main_content.setPrefWidth(getScreenWidth()*0.8);
        main_content.setPrefHeight(getScreenHeight());
    }
    public void menu() {
        barMenu.setDuration(Duration.millis(0.1));
        barMenu.setNode(barMaster);
        barMenu.setToX(-400);
        barMenu.play();

        barMaster.setTranslateX(0);

        barMenu.setOnFinished((ActionEvent e) -> {
            data.setVisible(true);
            data_close.setVisible(false);
        });
    }
    public void defaultPage() {
        try {
            Parent fxml = FXMLLoader.load(getClass().getResource("/fxml/Pages/DashboardAdmin.fxml"));
            main_content.getChildren().removeAll();
            main_content.getChildren().setAll(fxml);
        } catch (IOException ex) {
            Logger.getLogger(ModuleLayer.Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void btnNotActive(Button btn) {
        if (lastClickedButton != null) {
            lastClickedButton.getStyleClass().add("btn-not-active");
        }

        btn.getStyleClass().remove("btn-not-active");
        btn.getStyleClass().add("btn-active");
        lastClickedButton = btn;
    }
    public void menuNavigation() {
        btn_product.setOnAction(event -> {
            btnNotActive(btn_product);
            try {
                page(event, "/fxml/Master/Product.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_employee.setOnAction(event -> {
            btnNotActive(btn_employee);
            try {
                page(event, "/fxml/Master/Employee.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_position.setOnAction(event -> {
            btnNotActive(btn_position);
            try {
                page(event, "/fxml/Master/Position.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_supplier.setOnAction(event -> {
            btnNotActive(btn_supplier);
            try {
                page(event, "/fxml/Master/Distributor.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_product_category.setOnAction(event -> {
            btnNotActive(btn_product_category);
            try {
                page(event, "/fxml/Master/ProductCategory.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_discount.setOnAction(event -> {
            btnNotActive(btn_discount);
            try {
                page(event, "/fxml/Master/Discount.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_typeloyalty.setOnAction(event -> {
            btnNotActive(btn_typeloyalty);
            try {
                page(event, "/fxml/Master/MemberRoyalty.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_logout.setOnAction(event -> {
            btnNotActive(btn_logout);
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/LandingPage/Login.fxml"));
                Parent fxml = loader.load();
                Parent warungRoot = btn_logout.getScene().getRoot();
                ((StackPane) warungRoot).getChildren().setAll(fxml);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_dashboard.setOnAction(event -> {
            btnNotActive(btn_dashboard);
            try {
                page(event, "/fxml/Pages/DashboardAdmin.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_profile.setOnAction(event -> {
            btnNotActive(btn_profile);
            try {
                page(event, "/fxml/Pages/Profile.fxml");
            }catch (IOException ex){
                throw new RuntimeException(ex);
            }
        });
        btn_order.setOnAction(event -> {
            btnNotActive(btn_order);
            try {
                page(event, "/fxml/Transaction/Purchase.fxml");
            }catch (IOException ex){
                throw new RuntimeException(ex);
            }
        });
    }
    public void page(ActionEvent e, String path) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(path));
        Parent fxml = loader.load();
        main_content.getChildren().removeAll();
        main_content.getChildren().setAll(fxml);
        main_content.setAlignment(Pos.TOP_CENTER);
    }
    public void openMenu() {
        data.setOnAction(event -> {
            barMenu.setDuration(Duration.millis(400));
            barMenu.setNode(barMaster);
            barMenu.setToX(0);
            barMenu.play();
            barMaster.setTranslateX(-400);
            barMenu.setOnFinished((ActionEvent e) -> {
                data.setVisible(false);
                data_close.setVisible(true);
            });
            btnNotActive(data);
        });
    }
    public void getId(int id){
        this.id = id;
    }
    public void closeMenu() {
        data_close.setOnAction(event -> {
            barMenu.setDuration(Duration.millis(400));
            barMenu.setNode(barMaster);
            barMenu.setToX(-400);
            barMenu.play();

            barMaster.setTranslateX(0);

            barMenu.setOnFinished((ActionEvent e) -> {
                data.setVisible(true);
                data_close.setVisible(false);
            });
            btnNotActive(data_close);
        });
    }
}
