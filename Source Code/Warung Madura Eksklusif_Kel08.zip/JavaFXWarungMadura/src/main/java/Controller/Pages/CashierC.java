package Controller.Pages;

import Connection.DBConnect;
import Controller.LandingPage.LoginC;
import Controller.TransactionC.SaleC;
import Master.ProductCategory;
import SuperClassInterface.Controller;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.geometry.*;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;
import javafx.util.Duration;
import java.io.IOException;
import java.util.List;
import java.util.logging.*;

public class CashierC extends Controller {
    @FXML
    AnchorPane main, main_page;
    @FXML
    ScrollPane barMaster;
    @FXML
    VBox menu, menu_category;
    @FXML
    Label lbNamaKar;
    @FXML
    StackPane main_content;
    @FXML
    Button btn_dashboard, btn_profile, btn_member, open_order, close_order, btn_logout, btn_category;
    DBConnect connect = new DBConnect();
    private Button lastClickedButton;
    public static int id;
    ProductCategory pc = new ProductCategory();
    SaleC sale;
    TranslateTransition barMenu = new TranslateTransition();
    public void getId(int id){
        this.id = id;
    }

    public void initialize() {
        menu();
        openMenu();
        closeMenu();
        lbNamaKar.setText(lbNamaKar.getText().substring(0,9)+ LoginC.User.Name);
        menuNavigation();
        loadBtnCategory();
        main.setPrefHeight(getScreenHeight());
        menu.prefHeightProperty().bind(main.prefHeightProperty());
        menu.setPrefWidth(getScreenWidth()*0.2);
        main_content.setPrefWidth(getScreenWidth()*0.8);
        main_content.setPrefHeight(getScreenHeight());
        defaultPage();
    }
    public void setController(SaleC controller) {
        this.sale = controller;
    }
    public void defaultPage() {
        try {
            Parent fxml = FXMLLoader.load(getClass().getResource("/fxml/Pages/DashboardCashier.fxml"));
            main_content.getChildren().removeAll();
            main_content.getChildren().setAll(fxml);
        } catch (IOException ex) {
            Logger.getLogger(ModuleLayer.Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void btnNotActive(Button btn) {
        if (lastClickedButton != null) {
            lastClickedButton.getStyleClass().add("btn-not-active");
        }

        btn.getStyleClass().remove("btn-not-active");
        btn.getStyleClass().add("btn-active");
        lastClickedButton = btn;
    }
    public void menuNavigation() {
        btn_logout.setOnAction(event -> {
            btnNotActive(btn_logout);
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/LandingPage/Login.fxml"));
                Parent fxml = loader.load();
                Parent warungRoot = btn_logout.getScene().getRoot();
                ((StackPane) warungRoot).getChildren().setAll(fxml);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_dashboard.setOnAction(event -> {
            btnNotActive(btn_dashboard);
            try {
                page(event, "/fxml/Pages/DashboardCashier.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_profile.setOnAction(event -> {
            btnNotActive(btn_profile);
            try {
                page(event, "/fxml/Pages/Profile.fxml");
            }catch (IOException ex){
                throw new RuntimeException(ex);
            }
        });
        btn_member.setOnAction(event -> {
            btnNotActive(btn_member);
            try {
                page(event, "/fxml/Master/Member.fxml");
            }catch (IOException ex){
                throw new RuntimeException(ex);
            }
        });
        btn_category.setOnAction(event -> {
            btnNotActive(btn_category);
            try {
                page(event, "/fxml/Transaction/Sale.fxml");
            }catch (IOException ex){
                throw new RuntimeException(ex);
            }
        });
    }
    public void openMenu() {
        open_order.setOnAction(event -> {
            barMenu.setDuration(Duration.millis(400));
            barMenu.setNode(barMaster);
            barMenu.setToX(0);
            barMenu.play();
            barMaster.setTranslateX(-400);
            barMenu.setOnFinished((ActionEvent e) -> {
                open_order.setVisible(false);
                close_order.setVisible(true);
            });
            try {
                //page(event, "/fxml/Transaction/Sale.fxml");
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Transaction/Sale.fxml"));
                Parent fxml = loader.load();
                sale = loader.getController();
                setController(sale);
                main_content.getChildren().removeAll();
                main_content.getChildren().setAll(fxml);
                main_content.setAlignment(Pos.TOP_CENTER);
            }catch (IOException ex){
                alertError("Error :"+ex.getMessage());
            }
            btnNotActive(open_order);
        });
    }
    public void closeMenu() {
        close_order.setOnAction(event -> {
            barMenu.setDuration(Duration.millis(400));
            barMenu.setNode(barMaster);
            barMenu.setToX(-400);
            barMenu.play();

            barMaster.setTranslateX(0);

            barMenu.setOnFinished((ActionEvent e) -> {
                open_order.setVisible(true);
                close_order.setVisible(false);
            });
            btnNotActive(close_order);
        });
    }
    public void menu() {
        barMenu.setDuration(Duration.millis(0.1));
        barMenu.setNode(barMaster);
        barMenu.setToX(-400);
        barMenu.play();

        barMaster.setTranslateX(0);

        barMenu.setOnFinished((ActionEvent e) -> {
            open_order.setVisible(true);
            close_order.setVisible(false);
        });
    }
    public void page(ActionEvent e, String path) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(path));
        Parent fxml = loader.load();
        main_content.getChildren().removeAll();
        main_content.getChildren().setAll(fxml);
        main_content.setAlignment(Pos.TOP_CENTER);
    }
    public void loadBtnCategory(){
        List<ProductCategory> category = pc.getProductCategories(null,null);
        for (ProductCategory pc : category) {
            Button btn = new Button();
            btn.setAlignment(Pos.BASELINE_LEFT);
            btn.setPrefHeight(40.0);
            btn.setPrefWidth(400.0);
            btn.setStyle("-fx-text-fill: #64CCC5;");
            btn.setPadding(new Insets(0, 0, 0, 100));
            btn.setText(pc.getName());
            btn.setOnAction(event -> {
                sale.loadCard(pc.getIdCategories(btn.getText()));
                btnNotActive(btn);
            });
            menu_category.getChildren().add(btn);
        }
    }
}
