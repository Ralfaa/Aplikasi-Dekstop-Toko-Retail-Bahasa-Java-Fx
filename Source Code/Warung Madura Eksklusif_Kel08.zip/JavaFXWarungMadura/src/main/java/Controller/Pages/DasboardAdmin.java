package Controller.Pages;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;

import javax.swing.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


public class DasboardAdmin extends Controller {
    @FXML
    private AnchorPane main_content, ap_atas;
    @FXML
    VBox vb_content;
    @FXML
    Label lbIn, lbLow, lbCritically, lbOut, lbSellProduct, lbTotalProduc;
    @FXML
    TableView<InfoProduk> tbProduk;
    @FXML
    private TableColumn<InfoProduk, String> tcNama, tcNamaSupplier, tcStatus;
    DBConnect connect = new DBConnect();
    @FXML
    private TableColumn<InfoProduk, Integer> tcId, tcStock;

    public static class InfoProduk {
        private String id;
        private String status;
        private String supplier;
        private String name;
        private int quantity;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getSupplier() {
            return supplier;
        }

        public void setSupplier(String supplier) {
            this.supplier = supplier;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public InfoProduk(String idProduk, String supplier, String name, int quantity, String status) {
            this.id = idProduk;
            this.supplier = supplier;
            this.name = name;
            this.quantity = quantity;
            this.status = status;

        }
    }

    public void initialize() {
        layout();
        loadData();
        lbIn.setText(statusProduk("SELECT dbo.CountStatus1Produk() AS CountStatus1", "CountStatus1")+" Product");
        lbLow.setText(statusProduk("SELECT dbo.CountStatus2Produk() AS CountStatus2", "CountStatus2")+" Product");
        lbCritically.setText(statusProduk("SELECT dbo.CountStatus3Produk() AS CountStatus3", "CountStatus3")+" Product");
        lbOut.setText(statusProduk("SELECT dbo.CountStatus4Produk() AS CountStatus4", "CountStatus4")+" Product");
        lbSellProduct.setText(statusProduk("SELECT dbo.TotalQtyPenjualan() AS TotalQty", "TotalQty")+" Product");
        lbTotalProduc.setText(String.valueOf(totalCount("SELECT dbo.CountProduk() AS count", "count")));
    }

    public int statusProduk(String query, String param){
        int r = 0;
        try{
            connect.pstat = connect.conn.prepareStatement(query);
            connect.result = connect.pstat.executeQuery();

            if (connect.result.next()){
                r = connect.result.getInt(param);
            }
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return r;
    }

    public void loadData() {
        List<InfoProduk> productList = new ArrayList<>();
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM ProdukInfo";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                productList.add(new InfoProduk(connect.result.getString("ID Produk"),
                        connect.result.getString("Nama Supplier"),
                        connect.result.getString("Nama Produk"),
                        connect.result.getInt("Stock"),
                        connect.result.getString("Status")));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException ex) {
            alertError("Error :"+ex.getMessage());
        }

        tcId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tcNamaSupplier.setCellValueFactory(new PropertyValueFactory<>("supplier"));
        tcNama.setCellValueFactory(new PropertyValueFactory<>("name"));
        tcStock.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        tcStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        ObservableList<InfoProduk> buffer = FXCollections.observableArrayList(productList);
        tbProduk.setItems(buffer);
    }

    public void layout() {
        ap_atas.prefWidthProperty().bind(main_content.widthProperty());
        vb_content.prefWidthProperty().bind(main_content.widthProperty().subtract(20));
    }
    public int totalCount(String query, String param) {
        int r = 0;
        try {
            connect.pstat = connect.conn.prepareStatement(query);
            connect.result = connect.pstat.executeQuery();

            if (connect.result.next()) {
                r = connect.result.getInt(param);
            }
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return r;
    }
}
