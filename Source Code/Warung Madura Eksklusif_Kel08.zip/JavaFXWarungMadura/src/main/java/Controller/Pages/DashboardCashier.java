package Controller.Pages;

import Connection.DBConnect;
import Controller.LandingPage.LoginC;
import SuperClassInterface.Controller;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DashboardCashier extends Controller {
    @FXML
    TableView tbHistory;
    @FXML
    private TableColumn<HistoryTransaksi, String> tcIdTrs, tcMember, tcPromo, tcTotal;
    @FXML
    private TableColumn<HistoryTransaksi, Date> tcTgl;
    @FXML
    TextField tfSearch;
    @FXML
    Label lbtotalSell,lbTotalTrs;
    DBConnect connect = new DBConnect();

    public class HistoryTransaksi{
        private String idTrs,idMember,Promo,totalPrice;
        private Date Tanggal;

        public String getIdTrs() {return idTrs;}
        public void setIdTrs(String idTrs) {this.idTrs = idTrs;}
        public Date getTanggal() {return Tanggal;}
        public void setTanggal(Date tanggal) {Tanggal = tanggal;}
        public String getIdMember() {return idMember;}
        public void setIdMember(String idMember) {this.idMember = idMember;}
        public String getPromo() {return Promo;}
        public void setPromo(String promo) {Promo = promo;}
        public String getTotalPrice() {return totalPrice;}
        public void setTotalPrice(String totalPrice) {this.totalPrice = totalPrice;}

        public HistoryTransaksi(String idTrs, Date tanggal, String idMember, String Promo, String totalPrice) {
            this.idTrs = idTrs;
            Tanggal = tanggal;
            this.idMember = idMember;
            this.Promo = Promo;
            this.totalPrice = totalPrice;
        }
    }

    public void initialize(){
        loadData(LoginC.User.id);
        lbtotalSell.setText(formatRp(getTotalHargaTrs(LoginC.User.id)));
        lbTotalTrs.setText(getTotalTrs(LoginC.User.id)+" Transaction");
    }
    public void loadData(int id){
        List<HistoryTransaksi> historyTransaksi = getData(id);
        tcIdTrs.setCellValueFactory(new PropertyValueFactory<>("idTrs"));
        tcMember.setCellValueFactory(new PropertyValueFactory<>("idMember"));
        tcPromo.setCellValueFactory(new PropertyValueFactory<>("Promo"));
        tcTotal.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
        tcTgl.setCellValueFactory(new PropertyValueFactory<>("Tanggal"));
        ObservableList<HistoryTransaksi> buffer = FXCollections.observableArrayList(historyTransaksi);
        tbHistory.setItems(buffer);
    }

    public void loadSearch(){
        List<HistoryTransaksi> historyTransaksi = getDataSearch(LoginC.User.id, tfSearch.getText());
        tcIdTrs.setCellValueFactory(new PropertyValueFactory<>("idTrs"));
        tcMember.setCellValueFactory(new PropertyValueFactory<>("idMember"));
        tcPromo.setCellValueFactory(new PropertyValueFactory<>("Promo"));
        tcTotal.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
        tcTgl.setCellValueFactory(new PropertyValueFactory<>("Tanggal"));
        ObservableList<HistoryTransaksi> buffer = FXCollections.observableArrayList(historyTransaksi);
        tbHistory.setItems(buffer);
    }

    public List<HistoryTransaksi> getData(int id){
        List<HistoryTransaksi> purchaseList = new ArrayList<>();
        try{
            String view = "SELECT * FROM dbo.FnGetTransactionHistoryByEmployeeId(?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setInt(1, id);
            connect.pstat.setNull(2, Types.NULL);
            connect.result = connect.pstat.executeQuery();
            while(connect.result.next()){
                purchaseList.add(new HistoryTransaksi(connect.result.getString("id_transaksi"),
                        connect.result.getDate("TanggalTransaksi"),connect.result.getString("nama_pelanggan"),
                        connect.result.getString("nama_promo"), formatRp(connect.result.getDouble("TotalHarga"))));
            }
            connect.pstat.close();
            connect.result.close();
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return purchaseList;
    }
    public List<HistoryTransaksi> getDataSearch(int id,String phone){
        List<HistoryTransaksi> purchaseList = new ArrayList<>();
        try{
            String view = "SELECT * FROM dbo.FnGetTransactionHistoryByEmployeeId(?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setInt(1, id);
            if (phone.isEmpty()){
                connect.pstat.setNull(2, Types.NULL);
            }else{
                connect.pstat.setString(2, phone);
            }
            connect.result = connect.pstat.executeQuery();
            while(connect.result.next()){
                purchaseList.add(new HistoryTransaksi(connect.result.getString("id_transaksi"),
                        connect.result.getDate("TanggalTransaksi"),connect.result.getString("nama_pelanggan"),
                        connect.result.getString("nama_promo"), formatRp(connect.result.getDouble("TotalHarga"))));
            }
            connect.pstat.close();
            connect.result.close();
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return purchaseList;
    }
    public double getTotalHargaTrs(int id){
        double total = 0.0;
        try{
            String view = "SELECT * FROM dbo.FnGetTransactionHistoryByEmployeeId(?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setInt(1, id);
            connect.pstat.setNull(2, Types.NULL);
            connect.result = connect.pstat.executeQuery();
            while(connect.result.next()){
                total += connect.result.getDouble("TotalHarga");
            }
            connect.pstat.close();
            connect.result.close();
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return total;
    }
    public int getTotalTrs(int id){
        int i = 0;
        try{
            String view = "SELECT * FROM dbo.FnGetTransactionHistoryByEmployeeId(?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setInt(1, id);
            connect.pstat.setNull(2, Types.NULL);
            connect.result = connect.pstat.executeQuery();
            while(connect.result.next()){
                i++;
            }
            connect.pstat.close();
            connect.result.close();
        }catch (SQLException e){
            alertError("Error :"+e.getMessage());
        }
        return i;
    }
}
