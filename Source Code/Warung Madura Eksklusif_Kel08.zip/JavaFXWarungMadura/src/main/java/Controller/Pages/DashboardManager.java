package Controller.Pages;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class DashboardManager extends Controller {
    @FXML
    BarChart<String, Double> barChart;
    @FXML
    PieChart pieChart;
    @FXML
    Label lbMember, lbDistributor, lbProduct, lbEmployee, lbRevenue, lbExpenditure, lbOrders;
    @FXML
    ComboBox<String> cbTop;
    @FXML
    VBox vbox;
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    @FXML
    DatePicker dtStart, dtEnd;
    DBConnect connect = new DBConnect();

    public class RevenueExpenditure {
        private String period;
        private double revenue, expenditure;

        public String getPeriod() {
            return period;
        }

        public void setPeriod(String period) {
            this.period = period;
        }

        public double getRevenue() {
            return revenue;
        }

        public void setRevenue(double revenue) {
            this.revenue = revenue;
        }

        public double getExpenditure() {
            return expenditure;
        }

        public void setExpenditure(double expenditure) {
            this.expenditure = expenditure;
        }

        public RevenueExpenditure(String period, double revenue, double expenditure) {
            this.period = period;
            this.revenue = revenue;
            this.expenditure = expenditure;
        }
    }

    public class topProduct {
        private String namaproduct;
        private int totalSelling;

        public String getNamaproduct() {
            return namaproduct;
        }

        public void setNamaproduct(String namaproduct) {
            this.namaproduct = namaproduct;
        }

        public int getTotalSelling() {
            return totalSelling;
        }

        public void setTotalSelling(int totalSelling) {
            this.totalSelling = totalSelling;
        }

        public topProduct(String namaproduct, int totalSelling) {
            this.namaproduct = namaproduct;
            this.totalSelling = totalSelling;
        }
    }

    public void initialize() {
        cbTop.getItems().addAll("Top", "Bottom");
        loadBarChart(null, null);
        loadPieChart(null, null);
        lbRevenue.setText(formatRp(DisplayRevenue(null, null)));
        lbExpenditure.setText(formatRp(DisplayExpenditure(null, null)));
        lbOrders.setText(String.valueOf(DisplayOrders(null, null)));
        lbProduct.setText(String.valueOf(totalCount("SELECT dbo.CountProduk() AS count", "count")));
        lbDistributor.setText(String.valueOf(totalCount("SELECT dbo.CountSupplier() AS count", "count")));
        lbEmployee.setText(String.valueOf(totalCount("SELECT dbo.CountKaryawan() AS count", "count")));
        lbMember.setText(String.valueOf(totalCount("SELECT dbo.CountMember() AS count", "count")));
        cbTop.setOnAction(event -> {
            if (cbTop.getSelectionModel().getSelectedItem().equals("Top")) {
                pieChart.getData().clear();
                vbox.getChildren().clear();
                loadPieChart(null, null);
            }else{
                pieChart.getData().clear();
                vbox.getChildren().clear();
                loadPieChart2(null,null);
            }
        });
    }

    public void cb(){

    }

    public void loadBarChart(Date start, Date end) {
        XYChart.Series<String, Double> revenue = new XYChart.Series<>();
        XYChart.Series<String, Double> expenditure = new XYChart.Series<>();
        List<RevenueExpenditure> revenueExpenditures = getRevenueExpenditure(start, end);
        for (RevenueExpenditure re : revenueExpenditures) {
            revenue.getData().add(new XYChart.Data<>(re.getPeriod(), re.getRevenue()));
            expenditure.getData().add(new XYChart.Data<>(re.period, re.getExpenditure()));
        }
        revenue.setName("Revenue");
        expenditure.setName("Expenditure");
        barChart.getData().addAll(revenue, expenditure);
        for (XYChart.Series<String, Double> series : barChart.getData()) {
            for (XYChart.Data<String, Double> data : series.getData()) {
                Node node = data.getNode();
                node.autosize();
            }
        }
    }

    public void loadPieChart(Date start, Date end) {
        ObservableList<PieChart.Data> data = getTop5Product(start, end);
        pieChart.getData().addAll(data);
        pieChart.setTitle("Top 5 Best Selling Products");
        Color[] pieColors = {
                Color.rgb(93, 179, 224),
                Color.rgb(22, 68, 118),
                Color.rgb(22, 104, 150),
                Color.rgb(22, 123, 175),
                Color.rgb(62, 159, 209)
        };
        int i = 0;
        double total = 0.0;
        for (PieChart.Data d : data) {
            total += d.getPieValue();
        }
        for (PieChart.Data d : pieChart.getData()) {
            HBox legendItem = new HBox();
            Pane pane = new Pane();
            Label nameLabel = new Label(d.getName());
            nameLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 10));
            pane.setPrefSize(50, 10);
            d.getNode().setStyle("-fx-background-color: #" +
                    Integer.toHexString((int) (pieColors[i].getRed() * 255)) +
                    Integer.toHexString((int) (pieColors[i].getGreen() * 255)) +
                    Integer.toHexString((int) (pieColors[i].getBlue() * 255)) + ";");
            pane.setStyle("-fx-background-color: #" +
                    Integer.toHexString((int) (pieColors[i].getRed() * 255)) +
                    Integer.toHexString((int) (pieColors[i].getGreen() * 255)) +
                    Integer.toHexString((int) (pieColors[i].getBlue() * 255)) + ";");
            legendItem.getChildren().addAll(pane, nameLabel);
            vbox.getChildren().add(legendItem);
            double op = (d.getPieValue()/total)*100;
            d.setName(String.format("%.0f",op)+"%");
            i++;
        }
    }

    public void loadPieChart2(Date start, Date end) {
        ObservableList<PieChart.Data> data = getBottom5Product(start, end);
        pieChart.getData().addAll(data);
        pieChart.setTitle("Top 5 Best Selling Products");
        Color[] pieColors = {
                Color.rgb(93, 179, 224),
                Color.rgb(22, 68, 118),
                Color.rgb(22, 104, 150),
                Color.rgb(22, 123, 175),
                Color.rgb(62, 159, 209)
        };
        int i = 0;
        double total = 0.0;
        for (PieChart.Data d : data) {
            total += d.getPieValue();
        }
        for (PieChart.Data d : pieChart.getData()) {
            HBox legendItem = new HBox();
            Pane pane = new Pane();
            Label nameLabel = new Label(d.getName());
            nameLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 10));
            pane.setPrefSize(50, 10);
            d.getNode().setStyle("-fx-background-color: #" +
                    Integer.toHexString((int) (pieColors[i].getRed() * 255)) +
                    Integer.toHexString((int) (pieColors[i].getGreen() * 255)) +
                    Integer.toHexString((int) (pieColors[i].getBlue() * 255)) + ";");
            pane.setStyle("-fx-background-color: #" +
                    Integer.toHexString((int) (pieColors[i].getRed() * 255)) +
                    Integer.toHexString((int) (pieColors[i].getGreen() * 255)) +
                    Integer.toHexString((int) (pieColors[i].getBlue() * 255)) + ";");
            legendItem.getChildren().addAll(pane, nameLabel);
            vbox.getChildren().add(legendItem);
            double op = (d.getPieValue()/total)*100;
            d.setName(String.format("%.0f",op)+"%");
            i++;
        }
    }

    public void apply() {
        if(cbTop.getValue().equals("Top")){
            if (dtEnd.getValue() == null || dtStart.getValue() == null) {
                popup(popop_warning, deskWarning, "Date must be filled!!");
            }else if (dtStart.getValue().isAfter(dtEnd.getValue()) || dtEnd.getValue().isBefore(dtStart.getValue())) {
                popup(popop_warning, deskWarning, "Valid date!!");
            } else {
                barChart.getData().clear();
                pieChart.getData().clear();
                vbox.getChildren().clear();
                Date start = Date.valueOf(dtStart.getValue());
                Date end = Date.valueOf(dtEnd.getValue());
                loadBarChart(start, end);
                loadPieChart(start, end);
                lbRevenue.setText(formatRp(DisplayRevenue(start, end)));
                lbExpenditure.setText(formatRp(DisplayExpenditure(start, end)));
                lbOrders.setText(String.valueOf(DisplayOrders(start, end)));
            }
        }else{
            if (dtEnd.getValue() == null || dtStart.getValue() == null) {
                popup(popop_warning, deskWarning, "Date must be filled!!");
            }else if (dtStart.getValue().isAfter(dtEnd.getValue()) || dtEnd.getValue().isBefore(dtStart.getValue())) {
                popup(popop_warning, deskWarning, "Valid date!!");
            } else {
                barChart.getData().clear();
                pieChart.getData().clear();
                vbox.getChildren().clear();
                Date start = Date.valueOf(dtStart.getValue());
                Date end = Date.valueOf(dtEnd.getValue());
                loadBarChart(start, end);
                loadPieChart2(start, end);
                lbRevenue.setText(formatRp(DisplayRevenue(start, end)));
                lbExpenditure.setText(formatRp(DisplayExpenditure(start, end)));
                lbOrders.setText(String.valueOf(DisplayOrders(start, end)));
            }
        }

    }

    public void clear() {
        dtStart.setValue(null);
        dtEnd.setValue(null);

    }

    public void reset(){
        lbRevenue.setText(formatRp(DisplayRevenue(null, null)));
        lbExpenditure.setText(formatRp(DisplayExpenditure(null, null)));
        lbOrders.setText(String.valueOf(DisplayOrders(null, null)));
        dtStart.setValue(null);
        dtEnd.setValue(null);
        barChart.getData().clear();
        pieChart.getData().clear();
        vbox.getChildren().clear();
        loadBarChart(null,null);
        loadPieChart(null,null);
    }

    public List<RevenueExpenditure> getRevenueExpenditure(Date start, Date end) {
        List<RevenueExpenditure> revenueExpenditures = new ArrayList<>();
        try {
            connect.cstat = connect.conn.prepareCall("{call sp_GetRevenueExpenditure(?, ?)}");
            connect.cstat.setDate(1, (java.sql.Date) start);
            connect.cstat.setDate(2, (java.sql.Date) end);
            connect.result = connect.cstat.executeQuery();
            while (connect.result.next()) {
                revenueExpenditures.add(new RevenueExpenditure(connect.result.getString("Period"), connect.result.getDouble("Revenue"),
                        connect.result.getDouble("Expenditure")));
            }
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return revenueExpenditures;
    }

    public ObservableList<PieChart.Data> getTop5Product(Date start, Date end) {
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        try {
            connect.cstat = connect.conn.prepareCall("{call GetTop5BestSellingProducts(?, ?)}");
            connect.cstat.setDate(1, (java.sql.Date) start);
            connect.cstat.setDate(2, (java.sql.Date) end);
            connect.result = connect.cstat.executeQuery();
            while (connect.result.next()) {
                data.add(new PieChart.Data(connect.result.getString("NamaProduk"), connect.result.getInt("TotalTerjual")));
            }
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return data;
    }
    public ObservableList<PieChart.Data> getBottom5Product(Date start, Date end) {
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        try {
            connect.cstat = connect.conn.prepareCall("{call GetBottom10BestSellingProducts(?, ?)}");
            connect.cstat.setDate(1, (java.sql.Date) start);
            connect.cstat.setDate(2, (java.sql.Date) end);
            connect.result = connect.cstat.executeQuery();
            while (connect.result.next()) {
                data.add(new PieChart.Data(connect.result.getString("NamaProduk"), connect.result.getInt("TotalTerjual")));
            }
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return data;
    }

    public int totalCount(String query, String param) {
        int r = 0;
        try {
            connect.pstat = connect.conn.prepareStatement(query);
            connect.result = connect.pstat.executeQuery();

            if (connect.result.next()) {
                r = connect.result.getInt(param);
            }
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return r;
    }

    public double DisplayRevenue(Date start, Date end) {
        double rev = 0.0;
        try {
            connect.cstat = connect.conn.prepareCall("{? = call dbo.GetTotalHargaTransaksi(?,?)}");
            connect.cstat.setDate(2, (java.sql.Date) start);
            connect.cstat.setDate(3, (java.sql.Date) end);
            connect.cstat.registerOutParameter(1, Types.DOUBLE);
            connect.cstat.execute();
            rev = connect.cstat.getDouble(1);
            connect.cstat.close();
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return rev;
    }

    public double DisplayExpenditure(Date start, Date end) {
        double rev = 0.0;
        try {
            connect.cstat = connect.conn.prepareCall("{? = call dbo.GetTotalHargaTransaksiExpenditure(?,?)}");
            connect.cstat.setDate(2, (java.sql.Date) start);
            connect.cstat.setDate(3, (java.sql.Date) end);
            connect.cstat.registerOutParameter(1, Types.DOUBLE);
            connect.cstat.execute();
            rev = connect.cstat.getDouble(1);
            connect.cstat.close();
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return rev;
    }

    public int DisplayOrders(Date start, Date end) {
        int rev = 0;
        try {
            connect.cstat = connect.conn.prepareCall("{? = call dbo.GetJumlahTransaksiPenjualan(?,?)}");
            connect.cstat.setDate(2, (java.sql.Date) start);
            connect.cstat.setDate(3, (java.sql.Date) end);
            connect.cstat.registerOutParameter(1, Types.DOUBLE);
            connect.cstat.execute();
            rev = connect.cstat.getInt(1);
            connect.cstat.close();
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
        return rev;
    }
}
