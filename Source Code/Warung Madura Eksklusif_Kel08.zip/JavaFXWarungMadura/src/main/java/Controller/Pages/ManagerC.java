package Controller.Pages;

import Controller.LandingPage.LoginC;
import SuperClassInterface.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ManagerC extends Controller {
    @FXML
    AnchorPane main, main_page;
    @FXML
    VBox menu;
    @FXML
    Label lbNamaKar;
    @FXML
    StackPane main_content;
    @FXML
    Button btn_dashboard, btn_profile, btn_sales, btn_purchase_report, btn_logout;
    private Button lastClickedButton;
    public static int id;
    public void getId(int id){
        this.id = id;
    }

    public void initialize() {
        lbNamaKar.setText(lbNamaKar.getText().substring(0,9)+ LoginC.User.Name);
        menuNavigation();
        main.setPrefHeight(getScreenHeight());
        menu.prefHeightProperty().bind(main.prefHeightProperty());
        menu.setPrefWidth(getScreenWidth()*0.2);
        main_content.setPrefWidth(getScreenWidth()*0.8);
        main_content.setPrefHeight(getScreenHeight());
        defaultPage();
    }
    public void defaultPage() {
        try {
            Parent fxml = FXMLLoader.load(getClass().getResource("/fxml/Pages/DashboardManager.fxml"));
            main_content.getChildren().removeAll();
            main_content.getChildren().setAll(fxml);
            main_content.setAlignment(Pos.TOP_CENTER);
        } catch (IOException ex) {
            Logger.getLogger(ModuleLayer.Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void btnNotActive(Button btn) {
        if (lastClickedButton != null) {
            lastClickedButton.getStyleClass().add("btn-not-active");
        }

        btn.getStyleClass().remove("btn-not-active");
        btn.getStyleClass().add("btn-active");
        lastClickedButton = btn;
    }
    public void menuNavigation() {

        btn_logout.setOnAction(event -> {
            btnNotActive(btn_logout);
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/LandingPage/Login.fxml"));
                Parent fxml = loader.load();
                Parent warungRoot = btn_logout.getScene().getRoot();
                ((StackPane) warungRoot).getChildren().setAll(fxml);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_dashboard.setOnAction(event -> {
            btnNotActive(btn_dashboard);
            try {
                page(event, "/fxml/Pages/DashboardManager.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_profile.setOnAction(event -> {
            btnNotActive(btn_profile);
            try {
                page(event, "/fxml/Pages/Profile.fxml");
            }catch (IOException ex){
                throw new RuntimeException(ex);
            }
        });
        btn_sales.setOnAction(event -> {
            btnNotActive(btn_sales);
            try {
                page(event, "/fxml/Pages/SaleReport.fxml");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        btn_purchase_report.setOnAction(event -> {
            btnNotActive(btn_purchase_report);
            try {
                page(event, "/fxml/Pages/PurchaseReport.fxml");
            }catch (IOException ex){
                throw new RuntimeException(ex);
            }
        });
    }
    public void page(ActionEvent e, String path) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(path));
        Parent fxml = loader.load();
        main_content.getChildren().removeAll();
        main_content.getChildren().setAll(fxml);
        main_content.setAlignment(Pos.TOP_CENTER);
    }
}
