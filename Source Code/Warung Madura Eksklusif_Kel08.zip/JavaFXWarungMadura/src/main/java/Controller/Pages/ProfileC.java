package Controller.Pages;

import Connection.DBConnect;
import Controller.LandingPage.LoginC;
import SuperClassInterface.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

import javax.swing.*;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.SQLException;

public class ProfileC extends Controller {
    @FXML
    AnchorPane main_profile, main_content, ap_atas;
    @FXML
    HBox Hb_main;
    @FXML
    ImageView img, dtImage, imgIcon, imgdf;
    @FXML
    TextField dtID, dtUsername, dtName, dtEmail, dtPhone, dtGender, dtPosition;
    @FXML
    PasswordField dtPassword;
    @FXML
    TextArea dtAddress;
    @FXML
    Label Emp_Name;
    DBConnect connect = new DBConnect();
    private int id;
    private String nama;

    public void getId(int id){
        this.id = id;
    }

    @FXML
    public void initialize() {
        ap_atas.prefWidthProperty().bind(main_profile.widthProperty().subtract(2));
        img.fitWidthProperty().bind(main_profile.widthProperty().subtract(35));
        imgdf.fitWidthProperty().bind(main_profile.widthProperty().subtract(35));
        main_content.prefWidthProperty().bind(main_profile.widthProperty().subtract(35));
        Hb_main.prefHeightProperty().bind(main_profile.prefHeightProperty());
        profile();
        Emp_Name.setText(Emp_Name.getText().substring(0,9)+nama);
    }

    public void setImage() {
        String setimg = dtGender.getText().equals("Male") ? "/assets/Logo/Man.png" : "/assets/Logo/Women.png";
        imgIcon.setImage(new Image(getClass().getResourceAsStream(setimg)));
    }

    public void profile() {
        int idPosition = 0, id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Karyawan WHERE id_karyawan = " + LoginC.User.id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_karyawan");
                idPosition = connect.result.getInt("id_jabatan");
                dtName.setText(connect.result.getString("NamaKaryawan"));
                dtUsername.setText(connect.result.getString("Username"));
                dtPassword.setText(connect.result.getString("Password"));
                dtAddress.setText(connect.result.getString("Alamat"));
                dtPhone.setText(connect.result.getString("NoTelepon"));
                dtEmail.setText(connect.result.getString("Email"));
                dtGender.setText(connect.result.getString("JenisKelamin"));
                nama = connect.result.getString("NamaKaryawan");
                byte[] img = connect.result.getBytes("Picture");
                if (img != null) {
                    InputStream input = new ByteArrayInputStream(img);
                    Image image = new Image(input);
                    dtImage.setImage(image);
                }
            }
            dtID.setText(String.format("EMP%03d", id));
            dtPosition.setText(idPosition(idPosition));
            connect.stat.close();
            connect.result.close();
            setImage();

        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
    }

    public String idPosition(int id) {
        String nama = "";
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriJabatan WHERE id_jabatan = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                nama = connect.result.getString("NamaJabatan");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :"+e.getMessage());
        }
        return nama;
    }
}
