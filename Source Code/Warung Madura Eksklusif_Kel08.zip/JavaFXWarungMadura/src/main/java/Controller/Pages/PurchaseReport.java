package Controller.Pages;
import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static net.sf.jasperreports.engine.JasperFillManager.fillReport;

public class PurchaseReport extends Controller {
    @FXML
    TableView<ReportP> tbPurchase;
    @FXML
    TableColumn<ReportP, String> tcId, tcDate, tcSupplier, tcKaryawan, tcTotal;
    @FXML
    TextField tfId, tfDate, tfSupplier, tfKaryawan, tfTotal;
    @FXML
    DatePicker startDate, endDate;
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;
    DBConnect connect = new DBConnect();

    public static class ReportP{
        private String id, supplier, karyawan;
        private Date date;
        private String total;

        public String getId() {return id;}
        public void setId(String id) {this.id = id;}
        public String getSupplier() {return supplier;}
        public void setSupplier(String supplier) {this.supplier = supplier;}
        public String getKaryawan() {return karyawan;}
        public void setKaryawan(String karyawan) {this.karyawan = karyawan;}
        public Date getDate() {return date;}
        public void setDate(Date date) {this.date = date;}
        public String getTotal() {return total;}
        public void setTotal(String total) {this.total = total;}
        public ReportP(String id, String supplier, String karyawan, Date date, String total) {
            this.id = id;
            this.supplier = supplier;
            this.karyawan = karyawan;
            this.date = date;
            this.total = total;
        }
    }
    public void initialize() {
        loadData(null, null);
    }
    public void loadData(Date startDate, Date endDate){
        List<ReportP> purchaseList = getData(startDate,endDate);
        tcId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tcSupplier.setCellValueFactory(new PropertyValueFactory<>("supplier"));
        tcDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tcTotal.setCellValueFactory(new PropertyValueFactory<>("total"));
        tcKaryawan.setCellValueFactory(new PropertyValueFactory<>("karyawan"));
        ObservableList<ReportP> buffer = FXCollections.observableArrayList(purchaseList);
        tbPurchase.setItems(buffer);
    }

    public void apply(){
        if (startDate.getValue() == null || endDate.getValue() == null){
            popup(popop_warning, deskWarning, "The date cannot be empty!!");
        }else if (endDate.getValue().isBefore(startDate.getValue())){
            popup(popop_warning, deskWarning, "End date must be after start date!!");
        }else{
            loadData(Date.valueOf(startDate.getValue()), Date.valueOf(endDate.getValue()));
        }
    }
    public void reset(){
        startDate.setValue(null);
        endDate.setValue(null);
        loadData(null,null);
    }
    public void getDataTable(){
        ReportP rp = tbPurchase.getSelectionModel().getSelectedItem();
        tfId.setText(rp.getId());
        tfSupplier.setText(rp.getSupplier());
        tfDate.setText(rp.getDate().toString());
        tfTotal.setText(rp.getTotal());
        tfKaryawan.setText(rp.getKaryawan());
    }
    public void clear(){
        tfId.setText("");
        tfSupplier.setText("");
        tfDate.setText("");
        tfTotal.setText("");
        tfKaryawan.setText("");
    }
    public void print(){
        if (startDate.getValue() == null || endDate.getValue() == null){
            popup(popop_warning, deskWarning, "The date cannot be empty!!");
        }else if (endDate.getValue().isBefore(startDate.getValue())){
            popup(popop_warning, deskWarning, "End date must be after start date!!");
        }else{
            try {
                JasperReport jasperReport = JasperCompileManager.compileReport(getClass().getResourceAsStream("/report/ReportPurchase.jrxml"));
                Map<String, Object> param = new HashMap<>();
                param.put("StartDate", startDate.getValue());
                param.put("EndDate", endDate.getValue());
                JasperPrint print = fillReport(jasperReport, param, connect.conn);
                JasperViewer viewer = new JasperViewer(print, false);
                viewer.setVisible(true);
            }catch (JRException e){
                alertError("Error :"+e.getMessage());
            }
        }
    }
    public void detailPurchase(){
        if (tfId.getText().isEmpty()||tfDate.getText().isEmpty()||tfTotal.getText().isEmpty()||tfKaryawan.getText().isEmpty()||tfSupplier.getText().isEmpty()){
            popup(popop_warning, deskWarning, "The fields cannot be empty!!");
        }else{
            try {
                JasperReport jasperReport = JasperCompileManager.compileReport(getClass().getResourceAsStream("/report/HistoryPurchase.jrxml"));
                Map<String, Object> param = new HashMap<>();
                param.put("id_transaksi_pembelian", tfId.getText().substring(3));
                JasperPrint print = fillReport(jasperReport, param, connect.conn);
                JasperViewer viewer = new JasperViewer(print, false);
                viewer.setVisible(true);
            }catch (JRException e){
                alertError("Error :"+e.getMessage());
            }
        }
    }
    public List<ReportP> getData(Date startDate, Date endDate){
        List<ReportP> purchaseList = new ArrayList<>();
        try{
            String view = "SELECT * FROM dbo.FnGetPurchaseReport(?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setDate(1, startDate);
            connect.pstat.setDate(2, endDate);
            connect.result = connect.pstat.executeQuery();
            while(connect.result.next()){
                purchaseList.add(new ReportP(String.format("POD%03d",connect.result.getInt("id_transaksi")), connect.result.getString("nama_supplier"),
                        connect.result.getString("nama_karyawan"), connect.result.getDate("TanggalTransaksi"),
                        formatRp(connect.result.getDouble("TotalHarga"))));
            }
            connect.pstat.close();
            connect.result.close();
        }catch (SQLException e){
            alertError("Errot :"+e.getMessage());
        }
        return purchaseList;
    }
}
