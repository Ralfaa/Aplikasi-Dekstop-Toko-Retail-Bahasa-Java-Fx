package Controller.Pages;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static net.sf.jasperreports.engine.JasperFillManager.fillReport;

public class SaleReport extends Controller {
    @FXML
    TableView<ReportS> tbSale;
    @FXML
    TableColumn<ReportS, String> tcId, tcDate, tcMember, tcKaryawan, tcPromo, tcTotal;
    @FXML
    TextField tfId, tfDate, tfMember, tfKaryawan, tfPromo, tfTotal;
    @FXML
    DatePicker startDate, endDate;
    DBConnect connect = new DBConnect();
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning;

    public static class ReportS {
        private String id, member, karyawan, promo;
        private Date date;
        private String total;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getMember() {
            return member;
        }

        public void setMember(String member) {
            this.member = member;
        }

        public String getKaryawan() {
            return karyawan;
        }

        public void setKaryawan(String karyawan) {
            this.karyawan = karyawan;
        }

        public String getPromo() {
            return promo;
        }

        public void setPromo(String promo) {
            this.promo = promo;
        }

        public Date getDate() {
            return date;
        }

        public void setDate(Date date) {
            this.date = date;
        }

        public String getTotal() {
            return total;
        }

        public void setTotal(String total) {
            this.total = total;
        }

        public ReportS(String id, String member, String karyawan, String promo, Date date, String total) {
            this.id = id;
            this.member = member;
            this.karyawan = karyawan;
            this.date = date;
            this.total = total;
            this.promo = promo;
        }
    }

    public void initialize() {
        loadData(null, null);
    }

    public void loadData(Date startDate, Date endDate) {
        List<ReportS> purchaseList = getData(startDate, endDate);
        tcId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tcMember.setCellValueFactory(new PropertyValueFactory<>("member"));
        tcDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tcTotal.setCellValueFactory(new PropertyValueFactory<>("total"));
        tcKaryawan.setCellValueFactory(new PropertyValueFactory<>("karyawan"));
        tcPromo.setCellValueFactory(new PropertyValueFactory<>("promo"));
        ObservableList<ReportS> buffer = FXCollections.observableArrayList(purchaseList);
        tbSale.setItems(buffer);
    }

    public void apply() {
        if (startDate.getValue() == null || endDate.getValue() == null) {
            popup(popop_warning, deskWarning, "The date cannot be empty!!");
        } else if (endDate.getValue().isBefore(startDate.getValue())) {
            popup(popop_warning, deskWarning, "End date must be after start date!!");
        } else {
            loadData(Date.valueOf(startDate.getValue()), Date.valueOf(endDate.getValue()));
        }
    }

    public void reset() {
        loadData(null, null);
        startDate.setValue(null);
        endDate.setValue(null);
    }

    public void getDataTable() {
        ReportS rs = tbSale.getSelectionModel().getSelectedItem();
        tfId.setText(rs.getId());
        tfMember.setText(rs.getMember());
        tfPromo.setText(rs.getPromo());
        tfDate.setText(rs.getDate().toString());
        tfTotal.setText(rs.getTotal());
        tfKaryawan.setText(rs.getKaryawan());
    }

    public void clear() {
        tfId.setText("");
        tfMember.setText("");
        tfPromo.setText("");
        tfDate.setText("");
        tfTotal.setText("");
        tfKaryawan.setText("");
    }

    public void print() {
        if (startDate.getValue() == null || endDate.getValue() == null) {
            popup(popop_warning, deskWarning, "The date cannot be empty!!");
        } else if (endDate.getValue().isBefore(startDate.getValue())) {
            popup(popop_warning, deskWarning, "End date must be after start date!!");
        } else {
            try {
                JasperReport jasperReport = JasperCompileManager.compileReport(getClass().getResourceAsStream("/report/ReportSale.jrxml"));
                Map<String, Object> param = new HashMap<>();
                param.put("StartDate", startDate.getValue());
                param.put("EndDate", endDate.getValue());
                JasperPrint print = fillReport(jasperReport, param, connect.conn);
                JasperViewer viewer = new JasperViewer(print, false);
                viewer.setVisible(true);
            } catch (JRException e) {
                alertError("Error :" + e.getMessage());

            }
        }
    }

    public void detailSale() {
        if (tfId.getText().isEmpty() || tfDate.getText().isEmpty() || tfTotal.getText().isEmpty() || tfKaryawan.getText().isEmpty() || tfMember.getText().isEmpty()) {
            popup(popop_warning, deskWarning, "The fields cannot be empty!!");
        } else {
            try {
                JasperReport jasperReport = JasperCompileManager.compileReport(getClass().getResourceAsStream("/report/HistorySale.jrxml"));
                Map<String, Object> param = new HashMap<>();
                param.put("id_transaksi_penjualan", tfId.getText().substring(3));
                JasperPrint print = fillReport(jasperReport, param, connect.conn);
                JasperViewer viewer = new JasperViewer(print, false);
                viewer.setVisible(true);
            } catch (JRException e) {
                alertError("Error :" + e.getMessage());
            }
        }
    }

    public List<ReportS> getData(Date startDate, Date endDate) {
        List<ReportS> purchaseList = new ArrayList<>();
        try {
            String view = "SELECT * FROM dbo.FnGetSaleReport(?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setDate(1, startDate);
            connect.pstat.setDate(2, endDate);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                purchaseList.add(new ReportS(String.format("SNT%03d", connect.result.getInt("id_transaksi")), connect.result.getString("nama_pelanggan"),
                        connect.result.getString("nama_karyawan"), connect.result.getString("nama_promo"), connect.result.getDate("TanggalTransaksi"),
                        formatRp(connect.result.getDouble("TotalHarga"))));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Errot :" + e.getMessage());
        }
        return purchaseList;
    }
}
