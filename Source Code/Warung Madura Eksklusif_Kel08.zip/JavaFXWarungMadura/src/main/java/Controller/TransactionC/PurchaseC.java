package Controller.TransactionC;

import Connection.DBConnect;
import Controller.Component.*;
import Controller.Pages.AdminC;
import Master.*;
import SuperClassInterface.Controller;
import Transaction.Purchase;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.util.Duration;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

import static net.sf.jasperreports.engine.JasperFillManager.fillReport;

public class PurchaseC extends Controller {
    DBConnect connect = new DBConnect();
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning, lbId, lbTotalHarga;
    @FXML
    VBox card_container, trs_container;
    @FXML
    AnchorPane detail_container;
    @FXML
    Button btn_buy;
    @FXML
    ImageView dtImage;
    @FXML
    TextField tfSearch, dtID, dtName, dtCategories, dtSupplier, dtBuyPrice, dtSalePrice, dtStock, dtDiscount, dtStatus;
    @FXML
    ComboBox cbSupplier;
    ProductCategory pc = new ProductCategory();
    Supplier sp = new Supplier();
    Product prd = new Product();
    PurchaseCard controller = new PurchaseCard();
    Purchase purchase = new Purchase();
    TranslateTransition detail_card = new TranslateTransition();
    List<Pane> pane = new ArrayList<>();
    public static List<DataPembelian> product = new ArrayList<>();
    private ExecutorService executorService = Executors.newFixedThreadPool(1);


    public static class DataPembelian {
        private Product produk;
        private int qty;
        private double price;
        private List listPembelian = new ArrayList();

        public DataPembelian(Product idProduk, int qty, double price) {
            this.produk = idProduk;
            this.qty = qty;
            this.price = price;
        }

        public DataPembelian(Product idProduk, double price) {
            this.produk = idProduk;
            this.price = price;
        }

        public DataPembelian() {
        }

        public Product getProduk() {
            return produk;
        }

        public void setProduk(Product produk) {
            this.produk = produk;
        }

        public int getQty() {
            return qty;
        }

        public void setQty(int qty) {
            this.qty = qty;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public List getListPembelian() {
            return listPembelian;
        }

        public void insertTrs(Product produk, int qty, double price) {
            DataPembelian data = new DataPembelian(produk, qty, price);
            listPembelian.add(data);
        }
    }

    public void insertData() {
        List<DataPembelian> listPembelian = product;
        double totalHarga = 0.0;
        try {
            connect.cstat = connect.conn.prepareCall("{call SpInsertTransaksiPembelian(?,?,?,?)}");
            connect.cstat.setInt(1, sp.getIdSupplier(cbSupplier.getValue().toString()));
            connect.cstat.setInt(2, AdminC.id);

            SQLServerDataTable sda = new SQLServerDataTable();
            sda.addColumnMetadata("id_produk", Types.INTEGER);
            sda.addColumnMetadata("QTY", Types.INTEGER);
            sda.addColumnMetadata("Harga", Types.DOUBLE);
            for (DataPembelian data : listPembelian) {
                totalHarga += data.getProduk().getPurchasePrice() * data.getQty();
                sda.addRow(data.getProduk().getIdProduct(), data.getQty(), data.getProduk().getPurchasePrice() * data.getQty());
            }
            totalHarga = totalHarga + (totalHarga * 0.10);
            connect.cstat.setDouble(3, totalHarga);
            connect.cstat.setObject(4, sda);
            connect.cstat.execute();
            connect.cstat.close();
            popup(popop_success, deskSuccess, "Purchase Successfully!!");
            deleteList(trs_container);
            btn_buy.setDisable(true);
            JasperReport jasperReport = JasperCompileManager.compileReport(getClass().getResourceAsStream("/report/StrukOrderDistributor.jrxml"));
            Map<String, Object> param = new HashMap<>();
            param.put("id_transaksi_pembelian", Integer.parseInt(lbId.getText().substring(3)));
            JasperPrint print = fillReport(jasperReport, param, connect.conn);
            JasperViewer viewer = new JasperViewer(print, false);
            viewer.setVisible(true);
            purchase.getIdPurchaseTrs(lbId);
            product.clear();
        } catch (SQLException | JRException e) {
            alertError("Error :" + e.getMessage());
        }

    }


    public void initialize() {
        sp.getNameSupplier(cbSupplier);
        cbSupplier.setValue(cbSupplier.getItems().get(0));
        loadData();
        cbSupplier.setOnAction(event -> {
            loadData();
        });
        lbTotalHarga.setText(String.valueOf(controller.getTotal()));
        purchase.getIdPurchaseTrs(lbId);
    }

    public void lbHarga(double price) {
        lbTotalHarga.setText(formatRp(price));
        if (price > 0.0) {
            btn_buy.setDisable(false);
        } else {
            btn_buy.setDisable(true);
        }
    }

    public void loadData() {
        deleteList(card_container);
        List<Product> produck = prd.getProductBySupplier(sp.getIdSupplier(cbSupplier.getValue().toString()));
        loadCard(produck);
    }

    public void loadDataSearch() {
        deleteList(card_container);
        List<Product> products = prd.getProduct(tfSearch.getText());
        if (products.size() == 0) {
            popup(popop_warning, deskWarning, "No Product Found!!");
        } else {
            loadCard(products);
        }
    }

    public void loadCard(List<Product> productss) {
        deleteList(card_container);
        for (Product product : productss) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/ProductPurchaseCard.fxml"));
                    Pane newCard = loader.load();
                    ProductPurchaseCard ctrlcard = loader.getController();
                    ctrlcard.setController(PurchaseC.this);
                    ctrlcard.productDataCard(product.getIdProduct(), product.getName(), product.getQuantity());
                    return newCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> card_container.getChildren().add(newCard));
            });

            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void loadList(int id) {
        if (!checkTrs(id)) {
            List<Product> products = prd.getProduct(id);
            for (Product prd : products) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/PurchaseCard.fxml"));
                    Pane newCard = loader.load();
                    controller = loader.getController();
                    controller.setController(this);
                    product.add(new DataPembelian(prd, prd.getPurchasePrice()));
                    controller.productDataCard(prd.getIdProduct(), prd.getName(), prd.getPurchasePrice(), prd.getQuantity());
                    trs_container.getChildren().add(newCard);
                    pane.add(newCard);
                    cbSupplier.setDisable(true);
                } catch (IOException ex) {
                    alertError("Error :" + ex.getMessage());
                }
            }

        }
    }

    public boolean checkTrs(int id) {
        boolean check = false;
        for (DataPembelian p : product) {
            if (p.getProduk().getIdProduct() == id) {
                check = true;
            }
        }
        return check;
    }

    public void deleteList(Pane panee) {
        trs_container.getChildren().remove(panee);
        int i = pane.indexOf(panee);
        pane.remove(panee);
        if (i != -1 && i < product.size()) {
            product.remove(i);
        }
        if (pane.isEmpty()) {
            cbSupplier.setDisable(false);
        }
    }

    public void closeInfo() {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(0);
        detail_card.play();
        detail_container.setTranslateY(500);
    }

    public void openInfo(int id) {
        detail_card.setDuration(Duration.millis(200));
        detail_card.setNode(detail_container);
        detail_card.setToY(900);
        detail_card.play();
        detail_container.setTranslateY(-100);
        detailData(id);
    }

    public void detailData(int id) {
        int idCategory = 0;
        int idSupplier = 0;
        int ID = 0;
        int status = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Produk WHERE id_produk = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                ID = connect.result.getInt("id_produk");
                idCategory = connect.result.getInt("id_kategori");
                idSupplier = connect.result.getInt("id_supplier");
                dtName.setText(connect.result.getString("NamaProduk"));
                dtBuyPrice.setText(String.format("%.0f", connect.result.getBigDecimal("HargaBeli")));
                dtSalePrice.setText(String.format("%.0f", connect.result.getBigDecimal("HargaJual")));
                dtStock.setText(connect.result.getString("Stock"));
                dtDiscount.setText(connect.result.getString("PromoDiskon"));
                status = connect.result.getInt("Status");
                byte[] img = connect.result.getBytes("Picture");
                if (img != null) {
                    InputStream input = new ByteArrayInputStream(img);
                    Image image = new Image(input);
                    dtImage.setImage(image);
                } else {
                    dtImage.setImage(null);
                }
            }
            dtID.setText(String.format("PRD%03d", ID));

            String statusText = status == 1 ? "Active" :
                    status == 0 ? "Non Active" :
                            status == 2 ? "Low Stock" :
                                    status == 3 ? "Critically Low of Stock" :
                                            status == 4 ? "Out of Stock" : "Unknown";

            dtStatus.setText(statusText);
            dtCategories.setText(pc.getNameCategories(idCategory));
            dtSupplier.setText(sp.getNameSupplier(idSupplier));
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            alertError("Error :" + e.getMessage());
        }
    }
}
