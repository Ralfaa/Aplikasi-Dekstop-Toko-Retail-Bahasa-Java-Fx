package Controller.TransactionC;

import Connection.DBConnect;
import Controller.Component.*;
import Controller.Pages.CashierC;
import Master.*;
import SuperClassInterface.Controller;
import Transaction.Sale;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

public class SaleC extends Controller {
    @FXML
    GridPane gpCard;
    @FXML
    Pane popop_success, popop_information, popop_warning, popop_error;
    @FXML
    Label deskSuccess, deskError, deskInfo, deskWarning, lbTotalHarga, lbHargaSetelahDiskon, lbID, lbName;
    @FXML
    VBox trs_container;
    @FXML
    Button btn_buy;
    @FXML
    ComboBox cbDiscount;
    @FXML
    TextField tfPhoneMember, tfTotal, tfKembalian, tfSearch;
    DBConnect connect = new DBConnect();
    Product prd = new Product();
    Discount dis = new Discount();
    Member mbr = new Member();
    Sale sale = new Sale();

    List<Pane> pane = new ArrayList<>();
    public static List<DataPenjualan> product = new ArrayList<>();
    private ExecutorService executorService = Executors.newFixedThreadPool(1);

    public class DataPenjualan {
        private Product produk;
        private int qty;
        private double price;
        private List listPembelian = new ArrayList();

        public DataPenjualan(Product idProduk, int qty, double price) {
            this.produk = idProduk;
            this.qty = qty;
            this.price = price;
        }

        public DataPenjualan(Product idProduk, double price) {
            this.produk = idProduk;
            this.price = price;
        }

        public DataPenjualan() {
        }

        public Product getProduk() {
            return produk;
        }

        public void setProduk(Product produk) {
            this.produk = produk;
        }

        public int getQty() {
            return qty;
        }

        public void setQty(int qty) {
            this.qty = qty;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public List getListPembelian() {
            return listPembelian;
        }

        public void insertTrs(Product produk, int qty, double price) {
            DataPenjualan data = new DataPenjualan(produk, qty, price);
            listPembelian.add(data);
        }
    }

    public void initialize() {
        tfTotal.addEventFilter(KeyEvent.KEY_TYPED, this::setNumber);
        tfPhoneMember.addEventFilter(KeyEvent.KEY_TYPED, keyEvent -> {
            String chara = keyEvent.getCharacter();
            if (!chara.matches("[0-9]") && !chara.equals("\b") && !chara.equals("\n") || tfPhoneMember.getText().length() >= 13) {
                keyEvent.consume();
            }
        });
        loadData();
        sale.getIdSaleTrs(lbID);
        cbDiscount.setOnAction(event -> {
            double price = parseRp(lbTotalHarga.getText());
            getDiscountproduct(price);
            String nama = "";
            if (cbDiscount.getValue() != null) {
                nama = cbDiscount.getValue().toString();
            }
            double diskon =  price * (dis.getPercentageDiscount(dis.getIdDiscount(nama)) / 100.0);
            double setDiskon = price - diskon;
            lbHargaSetelahDiskon.setText(formatRp(setDiskon));
        });
    }

    public void inputMember() {
        if (mbr.getMemberIdByPhone(tfPhoneMember.getText()) > 0) {
            lbName.setText(lbName.getText().substring(0, 9) + mbr.getNameMember(mbr.getMemberIdByPhone(tfPhoneMember.getText())));
            cbDiscount.setDisable(false);
        } else {
            popup(popop_information, deskInfo, "No Member Found!!");
            lbName.setText("Member : N/A");
        }
        double price = parseRp(lbTotalHarga.getText());
        getDiscountproduct(price);
        String nama = "";
        if (cbDiscount.getValue() != null) {
            nama = cbDiscount.getValue().toString();
        }
        price = price - price * (dis.getPercentageDiscount(dis.getIdDiscount(nama)) / 100.0);
        lbHargaSetelahDiskon.setText(formatRp(price));
    }

    public void insertData() {
        cbDiscount.getValue();
        double totalHarga = 0.0;
        List<DataPenjualan> listPenjualan = product;
        try {
            connect.cstat = connect.conn.prepareCall("{call SpInsertTransaksiPenjualan(?,?,?,?,?)}");
            connect.cstat.setInt(1, CashierC.id);
            if (cbDiscount.getValue() == null) {
                connect.cstat.setNull(2, Types.NULL);
            } else {
                connect.cstat.setInt(2, dis.getIdDiscount((String) cbDiscount.getValue()));
            }
            if (tfPhoneMember.getText().isEmpty()) {
                connect.cstat.setNull(3, Types.NULL);
            } else {
                connect.cstat.setInt(3, mbr.getMemberIdByPhone(tfPhoneMember.getText()));
            }
            SQLServerDataTable detail = new SQLServerDataTable();
            detail.addColumnMetadata("id_produk", Types.INTEGER);
            detail.addColumnMetadata("Qty", Types.INTEGER);
            detail.addColumnMetadata("Harga", Types.DOUBLE);
            for (DataPenjualan data : listPenjualan) {
                totalHarga += data.getProduk().getSellingPrice() * data.getQty();
                detail.addRow(data.getProduk().getIdProduct(), data.getQty(), data.getPrice() * data.getQty());
            }
            connect.cstat.setDouble(4, totalHarga);
            connect.cstat.setObject(5, detail);
            connect.cstat.execute();
            connect.cstat.close();
            popup(popop_success, deskSuccess, "Sale Successfully!");
            deleteList(trs_container);
            product.clear();
            btn_buy.setDisable(true);
            JasperReport report = JasperCompileManager.compileReport(getClass().getResourceAsStream("/report/StrukOrder.jrxml"));
            Map<String, Object> params = new HashMap<>();
            params.put("id_transaksi_penjualan", Integer.parseInt(lbID.getText().substring(3)));
            params.put("cash", Double.parseDouble(tfTotal.getText()));
            params.put("Changes", Double.parseDouble(tfTotal.getText()) - parseRp(lbHargaSetelahDiskon.getText()));
            params.put("Point", Point(parseRp(lbHargaSetelahDiskon.getText())));

            JasperPrint print = JasperFillManager.fillReport(report, params, connect.conn);
            JasperViewer viewer = new JasperViewer(print, false);
            viewer.setVisible(true);
            sale.getIdSaleTrs(lbID);
        } catch (SQLException | JRException e) {
            alertError("Error :" + e.getMessage());
        }
    }


    public void changes() {
        double hargadis = parseRp(lbHargaSetelahDiskon.getText());
        tfKembalian.setText(formatRp(Double.parseDouble(tfTotal.getText()) - hargadis));
        if(Double.parseDouble(tfTotal.getText()) > hargadis){
            btn_buy.setDisable(false);
        }
    }

    public int Point(double price) {
        int point;
        point = price >= 50000.0 && price <= 100000.0 ? 1 :
                price >= 100001.0 && price <= 500000.0 ? 10 :
                        price >= 500001.0 && price <= 1000000.0 ? 50 :
                                price > 1000000.0 ? 70 : 0;
        return point;
    }

    public void getDiscountproduct(double minBeli) {
        cbDiscount.getItems().clear();
        MemberRoyalty mb = new MemberRoyalty();
        List<Discount> dc = dis.getDiscountByJenisMember(mb.getIdRoyalty(tfPhoneMember.getText()), minBeli);
        for (Discount d : dc) {
            cbDiscount.getItems().add(d.getName());
        }
    }

    public void loadData() {
        deleteList(gpCard);
        List<Product> produck = prd.getProduct();
        loadCard(produck);
    }

    public void loadDataSearch() {
        deleteList(gpCard);
        List<Product> products = prd.getProduct(tfSearch.getText());
        if (products.size() == 0) {
            popup(popop_warning, deskWarning, "No Product Found!!");
        } else {
            loadCard(products);
        }
    }

    public void loadCard(List<Product> produk) {
        final int[] column = {0};
        final int[] row = {0};
        for (Product p : produk) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/Component/ProductSaleCard.fxml"));
                    VBox vbCard = fxmlLoader.load();
                    ProductSaleCard controller = fxmlLoader.getController();
                    controller.setController(SaleC.this);
                    controller.productPurchaseCard(p.getIdProduct(), p.getName(), p.getSellingPrice(), p.getImage());
                    return vbCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> {
                    if (column[0] == 4) {
                        column[0] = 0;
                        row[0]++;
                    }
                    gpCard.add(newCard, column[0]++, row[0]);
                });
            });
            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void loadCard(int categoriProduct) {
        final int[] column = {0};
        final int[] row = {0};
        List<Product> produk = prd.getProductByCategory(categoriProduct);
        for (Product p : produk) {
            Task<Pane> task = new Task<Pane>() {
                protected Pane call() throws Exception {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/Component/ProductSaleCard.fxml"));
                    VBox vbCard = fxmlLoader.load();
                    ProductSaleCard controller = fxmlLoader.getController();
                    controller.setController(SaleC.this);
                    controller.productPurchaseCard(p.getIdProduct(), p.getName(), p.getSellingPrice(), p.getImage());
                    return vbCard;
                }
            };
            task.setOnSucceeded(event -> {
                Pane newCard = task.getValue();
                Platform.runLater(() -> {
                    if (column[0] == 4) {
                        column[0] = 0;
                        row[0]++;
                    }
                    gpCard.add(newCard, column[0]++, row[0]);
                });
            });
            task.setOnFailed(event -> Platform.runLater(() -> alertError("Error: " + task.getException().getMessage())));
            executorService.submit(task);
        }
    }

    public void lbHarga(double price) {
        lbTotalHarga.setText(formatRp(price));
        String nama = "";
        if (cbDiscount.getValue() != null) {
            nama = cbDiscount.getValue().toString();
        }
        price = price - price * (dis.getPercentageDiscount(dis.getIdDiscount(nama)) / 100.0);
        lbHargaSetelahDiskon.setText(formatRp(price));
    }

    public void loadList(int id) {
        if (!checkTrs(id)) {
            List<Product> products = prd.getProduct(id);
            for (Product prd : products) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Component/SaleCard.fxml"));
                    Pane newCard = loader.load();
                    SaleCard controller = loader.getController();
                    controller.setController(this);
                    product.add(new DataPenjualan(prd, hargaDiskon(prd.getSellingPrice(), prd.getPromo())));
                    controller.productDataCard(prd.getIdProduct(), prd.getName(), prd.getPromo(), prd.getSellingPrice(), prd.getQuantity());
                    trs_container.getChildren().add(newCard);
                    pane.add(newCard);
                } catch (IOException ex) {
                    alertError("Error :" + ex.getMessage());
                }
            }
        }
    }

    public double hargaDiskon(double hargaBeli, int persentase) {
        double harga = hargaBeli * (persentase / 100.0);
        return hargaBeli - harga;
    }

    public boolean checkTrs(int id) {
        for (DataPenjualan p : product) {
            if (p.getProduk().getIdProduct() == id) {
                return true;
            }
        }
        return false;
    }

    public void deleteList(Pane panee) {
        trs_container.getChildren().remove(panee);
        int i = pane.indexOf(panee);
        pane.remove(panee);

        if (i != -1 && i < product.size()) {
            product.remove(i);
        }
    }
}
