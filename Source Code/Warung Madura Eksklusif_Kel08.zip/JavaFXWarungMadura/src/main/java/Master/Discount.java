package Master;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Discount {
    private int id;
    private String name;
    private int idMember;
    private Date startDate;
    private Date endDate;
    private BigDecimal condition;
    private int discountPercentage;
    private String description;
    private int status;
    DBConnect connect = new DBConnect();
    Controller ctrl = new Controller();

    public Discount() {}
    public Discount(int id, String name, int idMember, Date startDate, Date endDate, BigDecimal condition, int discountPercentage, String description, int status) {
        this.id = id;
        this.name = name;
        this.idMember = idMember;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.condition = condition;
        this.discountPercentage = discountPercentage;
        this.status = status;
    }

    public Discount(int idPromoDiskon, String namaPromo, int idJenisMember, BigDecimal syaratMinPembelian, int persentaseDiskon, String deskripsi, int status) {
        this.id = idPromoDiskon;
        this.name = namaPromo;
        this.idMember = idJenisMember;
        this.description = deskripsi;
        this.condition = syaratMinPembelian;
        this.discountPercentage = persentaseDiskon;
        this.status = status;
    }
    public Discount(int idPromoDiskon, String namaPromo, int persentaseDiskon) {
        this.id = idPromoDiskon;
        this.name = namaPromo;
        this.discountPercentage = persentaseDiskon;
    }

    public int getIdDiscount() {return id;}
    public void setId(int id) {this.id = id;}
    public String getDescription() {return description;}
    public void setDescription(String description) {this.description = description;}
    public Date getStartDate() {return startDate;}
    public void setStartDate(Date startDate) {this.startDate = startDate;}
    public Date getEndDate() {return endDate;}
    public void setEndDate(Date endDate) {this.endDate = endDate;}
    public BigDecimal getCondition() {return condition;}
    public void setCondition(BigDecimal condition) {this.condition = condition;}
    public int getDiscountPercentage() {return discountPercentage;}
    public void setDiscountPercentage(int discountPercentage) {this.discountPercentage = discountPercentage;}
    public int getStatus() {return status;}
    public void setStatus(int status) {this.status = status;}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdMember() {
        return idMember;
    }

    public void setIdMember(int idMember) {
        this.idMember = idMember;
    }
    public List<Discount> getDiscountByJenisMember(int idJenisMember, double minBeli) {
        List<Discount> discounts = new ArrayList<>();
        try {
            String view = "SELECT * FROM dbo.GetPromoDiskonByMinPembelianAndMemberId(?, ?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setDouble(1, minBeli);
            connect.pstat.setInt(2, idJenisMember);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                discounts.add(new Discount(connect.result.getInt("id_promo"), connect.result.getString("NamaPromo"),
                        connect.result.getInt("Persentase_Diskon")));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return discounts;
    }

    public Discount Result(ResultSet result) throws SQLException {
        return new Discount(result.getInt("id_promo"), result.getString("NamaPromo"),
                result.getInt("id_jenis_member"),result.getDate("TanggalMulai"),
                result.getDate("TanggalAkhir"),result.getBigDecimal("SyaratMinPembelian"),
                result.getInt("Persentase_Diskon"),result.getString("Deskripsi"),
                result.getInt("Status"));
    }
    public List<Discount> getDiscount(ComboBox cb, double minBeli) {
        List<Discount> discounts = new ArrayList<>();
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM PromoDiskon WHERE Status = 1 AND SyaratMinPembelian = '" + minBeli + "'";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                cb.getItems().add(connect.result.getString("NamaPromo"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return discounts;
    }

    //  Filter
    public List<Discount> getDiscount(String combobox1, String search, String combobox2) {
        List<Discount> discounts = new ArrayList<>();
        try {
            String view = "SELECT * FROM dbo.FnSearchPromoDiskon(?,?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1, combobox1);
            connect.pstat.setString(2, search);
            connect.pstat.setString(3, combobox2);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                discounts.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return discounts;
    }

    // Auto Id
    public void getIdDiscount(TextField tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM PromoDiskon";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_promo");
            }
            connect.stat.close();
            connect.result.close();
            tfID.setText(String.format("DSC%03d",id+1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }

    public int getIdDiscount(String tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM PromoDiskon WHERE NamaPromo = '"+tfID+"'";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_promo");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return id;
    }
    public int getPercentageDiscount(int ID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM PromoDiskon WHERE id_promo = '"+ID+"'";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("Persentase_Diskon");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return id;
    }
}
