package Master;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.TextField;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Employee {
    private int id;
    private int idJabatan;
    private String username;
    private String name;
    private String address;
    private String phone;
    private String email;
    private String gender;
    private String password;
    private int status;
    Controller ctrl = new Controller();
    DBConnect connect = new DBConnect();
    public Employee(int id, int idJabatan, String username, String name, String address, String phone, String email, String gender, String password, int status) {
        this.id = id;
        this.idJabatan = idJabatan;
        this.username = username;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.gender = gender;
        this.status = status;
        this.password = password;
    }
    public Employee(int id, String name, int idJabatan, int status){
        this.id = id;
        this.name = name;
        this.idJabatan = idJabatan;
        this.status = status;
    }
    public Employee(){}
    public int getIdEmployee() {return id;}
    public void setId(int id) {this.id = id;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
    public String getUsername() {return username;}
    public void setUsername(String username) {this.username = username;}
    public String getAddress() {return address;}
    public void setAddress(String address) {this.address = address;}
    public String getPhone() {return phone;}
    public void setPhone(String phone) {this.phone = phone;}
    public String getEmail() {return email;}
    public void setEmail(String email) {this.email = email;}
    public String getGender() {return gender;}
    public void setGender(String gender) {this.gender = gender;}
    public int getStatus() {return status;}
    public void setStatus(int status) {this.status = status;}
    public int getIdJabatan() {return idJabatan;}
    public void setIdJabatan(int idJabatan) {this.idJabatan = idJabatan;}
    public String getPassword() {return password;}
    public void setPassword(String password) {this.password = password;}
    public List<Employee> getEmployee(String combobox1, String search, String combobox2) {
        List<Employee> employees = new ArrayList<>();
        try {
            String view = "SELECT * FROM dbo.FnSearchEmployee(?, ?, ?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1, combobox1);
            connect.pstat.setString(2, search);
            connect.pstat.setString(3, combobox2);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                employees.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return employees;
    }
    public Employee Result(ResultSet result) throws SQLException {
        return new Employee(result.getInt("id_karyawan"), result.getInt("id_jabatan"),
                result.getString("Username"), result.getString("NamaKaryawan"),
                result.getString("Alamat"), result.getString("NoTelepon"),
                result.getString("Email"),result.getString("JenisKelamin"),
                result.getString("Password"), result.getInt("Status"));
    }
    public byte[] getImageEmpFromDatabase(int employeeId) {
        byte[] image = null;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT Picture FROM Karyawan WHERE id_karyawan = " + employeeId;
            connect.result = connect.stat.executeQuery(view);
            if (connect.result.next()) {
                image = connect.result.getBytes("Picture");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());

        }
        return image;
    }

    // Auto Id
    public void getIdEmployee(TextField tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Karyawan";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_karyawan");
            }
            connect.stat.close();
            connect.result.close();
            tfID.setText(String.format("EMP%03d", id + 1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
}