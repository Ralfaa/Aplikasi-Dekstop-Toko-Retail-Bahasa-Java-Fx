package Master;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Member {
    private int id;
    private String name;
    private int idJMember;
    private String address;
    private String telpNumber;
    private String email;
    private int point;
    private int status;
    DBConnect connect = new DBConnect();
    Controller ctrl = new Controller();

    public Member() {}
    public Member(int id, String name, int idjMember, String address, String telpNumber, String email, int point, int status) {
        this.id = id;
        this.name = name;
        this.idJMember = idjMember;
        this.address = address;
        this.telpNumber = telpNumber;
        this.email = email;
        this.point = point;
        this.status = status;
    }
    public Member(int id, String name, int idjMember, int point, int status) {
        this.id = id;
        this.name = name;
        this.idJMember = idjMember;
        this.point = point;
        this.status = status;
    }
    public int getId() {return id;}
    public void setId(int id) {this.id = id;}
    public int getStatus() {return status;}
    public void setStatus(int status) {this.status = status;}
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getIdJMember() {
        return idJMember;
    }
    public void setIdJMember(int idJMember) {
        this.idJMember = idJMember;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getTelpNumber() {
        return telpNumber;
    }
    public void setTelpNumber(String telpNumber) {
        this.telpNumber = telpNumber;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public int getPoint() {
        return point;
    }
    public void setPoint(int point) {
        this.point = point;
    }

    // For Filter
    public List<Member> getMember(String combobox1, String search, String combobox2) {
        List<Member> members = new ArrayList<>();
        try {
            String view = "SELECT * FROM FnSearchMember(?,?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1, combobox1);
            connect.pstat.setString(2, search);
            connect.pstat.setString(3, combobox2);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                members.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return members;
    }
    public Member Result (ResultSet result) throws SQLException {
        return new Member(result.getInt("id_member"), result.getString("NamaMember"),
                result.getInt("id_jenis_member"), result.getString("Alamat"),
                result.getString("NoTelepon"), result.getString("Email"),
                result.getInt("Point"), result.getInt("Status"));
    }
    // Auto Id
    public void MemberId(TextField tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Member";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_member");
            }
            connect.stat.close();
            connect.result.close();
            tfID.setText(String.format("MBR%03d",id+1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
    public int getMemberIdByPhone(String val) {
        int id = 0;
        try {
            String view = "SELECT * FROM dbo.GetMemberDetailsByNoTelepon(?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1, val);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                id = connect.result.getInt("id_member");
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return id;
    }
    public String getNameMember(int  id) {
        String nama = "";
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Member WHERE id_member = "+id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                nama = connect.result.getString("nama");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return nama;
    }
    public void getNameMember(ComboBox cb) {
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM JenisMember";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                cb.getItems().add(connect.result.getString("nama"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
}
