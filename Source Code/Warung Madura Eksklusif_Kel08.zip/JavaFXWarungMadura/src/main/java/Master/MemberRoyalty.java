package Master;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.TextField;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemberRoyalty {
    private int id;
    private String Name;
    private int MinPoint;
    private int status;
    DBConnect connect = new DBConnect();
    Controller ctrl = new Controller();

    public MemberRoyalty(int id, String name, int MP, int status) {
        this.id = id;
        this.Name = name;
        this.MinPoint = MP;
        this.status = status;
    }

    public MemberRoyalty() {
    }

    public int getIdRoyalty() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getMinPoint() {
        return MinPoint;
    }

    public void setMinPoint(int minPoint) {
        MinPoint = minPoint;
    }

    // For Filter
    public List<MemberRoyalty> getMemberRoyalty(String comboBox, String search) {
        List<MemberRoyalty> memberRoyalties = new ArrayList<>();
        try {
            String view = "SELECT * FROM dbo.FnSearchJenisMember(?,?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1, comboBox);
            connect.pstat.setString(2, search);
            connect.pstat.setString(3, null);
//            if (comboBox == null) {
//                connect.pstat.setString(1, null);
//                connect.pstat.setString(2, null);
//                connect.pstat.setString(3, null);
//            } else {
//                connect.pstat.setString(1, search);
//                if (comboBox.equals("Min Point")) {
//                    connect.pstat.setString(2, null);
//                    connect.pstat.setString(3, comboBox);
//                } else {
//                    connect.pstat.setString(2, comboBox);
//                    connect.pstat.setString(3, null);
//                }
//            }

            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                memberRoyalties.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :" + e.getMessage());
        }
        return memberRoyalties;
    }

    public MemberRoyalty Result(ResultSet result) throws SQLException {
        return new MemberRoyalty(result.getInt("id_jenis_member"), result.getString("Nama"),
                result.getInt("MinPoint"), result.getInt("Status"));
    }

    //Auto Id
    public void getIdRoyalty(TextField tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM JenisMember";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_jenis_member");
            }
            connect.stat.close();
            connect.result.close();
            tfID.setText(String.format("MRY%02d", id + 1));
        } catch (SQLException e) {
            ctrl.alertError("Error :" + e.getMessage());
        }
    }

    public int getIdRoyalty(String val) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Member WHERE NoTelepon = '" + val + "'";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_jenis_member");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :" + e.getMessage());
        }
        return id;
    }

    // Name Category By Id
    public String getNameCategoryMember(int id) {
        String nama = "";
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM JenisMember WHERE id_jenis_member = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                nama = connect.result.getString("Nama");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :" + e.getMessage());
        }
        return nama;
    }
}