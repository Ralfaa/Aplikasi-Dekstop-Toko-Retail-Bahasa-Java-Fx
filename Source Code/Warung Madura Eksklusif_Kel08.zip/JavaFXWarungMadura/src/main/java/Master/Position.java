package Master;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Position {
    private int id;
    private String name;
    private String akses;
    private int status;
    DBConnect connect = new DBConnect();
    Controller ctrl = new Controller();

    public Position(int id, String name, String akses, int status) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.akses = akses;
    }

    public Position() {}
    public int getIdPosition() {return id;}
    public void setId(int id) {this.id = id;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
    public String getAkses() {return akses;}
    public void setAkses(String akses) {this.akses = akses;}
    public int getStatus() {return status;}
    public void setStatus(int status) {this.status = status;}

    // Name Position By Id
    public String getNamePosition(int id) {
        String nama = "";
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriJabatan WHERE id_jabatan = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                nama = connect.result.getString("NamaJabatan");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return nama;
    }
    // Name Position For Cb
    public void getNamePosition(ComboBox cb1) {
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriJabatan";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                cb1.getItems().add(connect.result.getString("NamaJabatan"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
    // Id Position By Name
    public int getIdPosition(String value) {
        int id = 0;
        try {
            connect.cstat = connect.conn.prepareCall("{ ? = call GetJabatanIdByName(?) }");
            connect.cstat.setString(2, value);
            connect.cstat.registerOutParameter(1, java.sql.Types.INTEGER);
            connect.cstat.execute();
            id = connect.cstat.getInt(1);
        } catch (SQLException ex) {
            ctrl.alertError("Error :"+ex.getMessage());
        }
        return id;
    }

    // For Filter
    public List<Position> getPosition(String comboBox, String search){
        List<Position> positions = new ArrayList<>();
        try{
            String view = "SELECT * FROM FnSearchPosition(?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1,comboBox);
            connect.pstat.setString(2,search);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()){
                positions.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        }catch (SQLException e){
            ctrl.alertError("Error :"+e.getMessage());
        }
        return positions;
    }
    public Position Result(ResultSet result) throws SQLException {
        return new Position(result.getInt("id_jabatan"), result.getString("NamaJabatan"),
                result.getString("Akses"), result.getInt("Status"));
    }
    // Auto Id
    public void getIdPosition(TextField tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriJabatan";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_jabatan");
            }
            connect.stat.close();
            connect.result.close();
            tfID.setText(String.format("PST%02d",id+1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
}
