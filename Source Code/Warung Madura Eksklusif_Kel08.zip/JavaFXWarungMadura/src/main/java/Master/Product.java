package Master;


import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.TextField;

import java.sql.*;
import java.util.*;

public class Product {
    private int id;
    private int idSupplier;
    private int idProductCategory;
    private String name;
    private double sellingPrice;
    private double purchasePrice;
    private int promo;
    private int quantity;
    private int status;
    private byte[] image;
    DBConnect connect = new DBConnect();
    Controller ctrl = new Controller();

    public Product() {}
    public Product(int id, int idSupplier, int idProductCategory, String name, double sellingPrice, double purchasePrice, int quantity, int status, int promo, byte[] image){
        this.id = id;
        this.idSupplier = idSupplier;
        this.idProductCategory = idProductCategory;
        this.name = name;
        this.sellingPrice = sellingPrice;
        this.purchasePrice = purchasePrice;
        this.quantity = quantity;
        this.status = status;
        this.promo = promo;
        this.image = image;
    }
    public Product(int id, String name, double sellingPrice, double purchasePrice, byte[] image){
        this.id = id;
        this.name = name;
        this.sellingPrice = sellingPrice;
        this.purchasePrice = purchasePrice;
        this.image = image;
    }
    public Product(int id, int idSupplier, int idProductCategory, double sellingPrice, String name, int status, byte[] image, int promo){
        this.id = id;
        this.idSupplier = idSupplier;
        this.idProductCategory = idProductCategory;
        this.sellingPrice = sellingPrice;
        this.name = name;
        this.status = status;
        this.image = image;
        this.promo = promo;
    }
    public int getIdProduct() {return id;}
    public void setId(int id) {this.id = id;}
    public int getIdSupplier() {return idSupplier;}
    public void setIdSupplier(int idSupplier) {this.idSupplier = idSupplier;}
    public int getIdProductCategory() {return idProductCategory;}
    public void setIdProductCategory(int idProductCategory) {this.idProductCategory = idProductCategory;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
    public int getPromo() {return promo;}
    public void setPromo(int promo) {this.promo = promo;}
    public double getSellingPrice() {return sellingPrice;}
    public void setSellingPrice(double sellingPrice) {this.sellingPrice = sellingPrice;}
    public double getPurchasePrice() {return purchasePrice;}
    public void setPurchasePrice(double purchasePrice) {this.purchasePrice = purchasePrice;}
    public int getQuantity() {return quantity;}
    public void setQuantity(int quantity) {this.quantity = quantity;}
    public int getStatus() {return status;}
    public void setStatus(int status) {this.status = status;}
    public byte[] getImage() {return image;}
    public void setImage(byte[] image) {this.image = image;}
    public List<Product> getProduct(String sortBy, String categoryName, String supplierName) {
        List<Product> products = new ArrayList<>();
        try {
            String view = "SELECT * FROM FnSearchProduk(?,?,?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1, sortBy);
            connect.pstat.setNull(2, Types.NULL);
            connect.pstat.setString(3, categoryName);
            connect.pstat.setString(4, supplierName);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                products.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return products;
    }
    public List<Product> getProduct(String search) {
        List<Product> products = new ArrayList<>();
        try {
            String view = "SELECT * FROM FnSearchProduk(?,?,?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setNull(1, Types.NULL);
            connect.pstat.setString(2, search);
            connect.pstat.setNull(3, Types.NULL);
            connect.pstat.setNull(4, Types.NULL);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                products.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return products;
    }
    public List<Product> getProduct() {
        List<Product> products = new ArrayList<>();
        try {
            String view = "SELECT * FROM FnSearchProduk(?,?,?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setNull(1, Types.NULL);
            connect.pstat.setNull(2, Types.NULL);
            connect.pstat.setNull(3, Types.NULL);
            connect.pstat.setNull(4, Types.NULL);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                products.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return products;
    }
    public Product Result(ResultSet result) throws SQLException {
        return new Product(result.getInt("id_produk"), result.getInt("id_supplier"),
                result.getInt("id_kategori"), result.getString("NamaProduk"),
                result.getDouble("HargaJual"), result.getDouble("HargaBeli"),
                result.getInt("Stock"), result.getInt("Status"),
                result.getInt("PromoDiskon"),result.getBytes("Picture"));
    }

    // Get Product By Id
    public List<Product> getProduct(int id) {
        List<Product> products = new ArrayList<>();
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Produk WHERE id_produk = "+id;
            connect.result = connect.stat.executeQuery(view);
            if (connect.result.next()) {
                products.add(Result(connect.result));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return products;
    }

    // Product By Supplier Id
    public List<Product> getProductBySupplier(int id) {
        List<Product> products = new ArrayList<>();
        try {
            String view = "SELECT * FROM dbo.FnGetProductsBySupplierId(?) WHERE Status != 0";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setInt(1, id);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                products.add(Result(connect.result));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return products;
    }

    public List<Product> getProductByCategory(int id) {
        List<Product> products = new ArrayList<>();
        try {
            String view = "SELECT * FROM dbo.FnGetProductsByKategoriId(?) WHERE Status != 0";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setInt(1, id);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()) {
                products.add(Result(connect.result));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return products;
    }

    // Auto Id
    public void getIdProduct(TextField tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Produk";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_produk");
            }
            connect.stat.close();
            connect.result.close();
            tfID.setText(String.format("PRD%03d",id+1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
    public byte[] getImageFromDatabase(int productId) {
        byte[] image = null;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Produk WHERE id_produk = " + productId;
            connect.result = connect.stat.executeQuery(view);
            if (connect.result.next()) {
                image = connect.result.getBytes("Picture");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return image;
    }
}
