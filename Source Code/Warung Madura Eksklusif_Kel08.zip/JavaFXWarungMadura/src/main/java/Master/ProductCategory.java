package Master;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductCategory {
    private int id;
    private String name;
    private String Unit;
    private int status;
    DBConnect connect = new DBConnect();
    Controller ctrl = new Controller();
    public ProductCategory() {}

    public ProductCategory(int id, String name, String unit, int status) {
        this.id = id;
        this.name = name;
        Unit = unit;
        this.status = status;
    }
    public int getIdProductCategory() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getUnit() {
        return Unit;
    }
    public void setUnit(String unit) {
        Unit = unit;
    }
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }

    // Filter
    public List<ProductCategory> getProductCategories(String comboBox, String search){
        List<ProductCategory> productCategories = new ArrayList<>();
        try{
            String view = "SELECT * FROM dbo.FnSearchProductCategory(?, ?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1,comboBox);
            connect.pstat.setString(2,search);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()){
                productCategories.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        }catch (SQLException e){
                ctrl.alertError("Error :"+e.getMessage());
        }
        return productCategories;
    }
    public ProductCategory Result(ResultSet result) throws SQLException {
        return new ProductCategory(result.getInt("id_kategori"), result.getString("NamaKategori"),
                result.getString("Satuan"), result.getInt("Status"));
    }

    // Auto Id
    public void getIdProductCategory(TextField tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriProduk";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_kategori");
            }
            connect.stat.close();
            connect.result.close();
            tfID.setText(String.format("UNT%02d",id+1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }

    // Id Category By Name
    public int getIdCategories(String value) {
        int id=0;
        try {
            connect.cstat = connect.conn.prepareCall("{ ? = call GetKategoriIdByName(?) }");
            connect.cstat.setString(2, value);
            connect.cstat.registerOutParameter(1, java.sql.Types.INTEGER);
            connect.cstat.execute();
            id = connect.cstat.getInt(1);
        } catch (SQLException ex) {
            ctrl.alertError("Error :"+ex.getMessage());
        }
        return id;
    }

    // Name Cateogry By Id
    public String getNameCategories(int id) {
        String nama = "";
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriProduk WHERE id_kategori = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                nama = connect.result.getString("NamaKategori");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return nama;
    }

    // Name Cateogry For Cb
    public void getNameCategories(ComboBox cb) {
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM KategoriProduk";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                cb.getItems().add(connect.result.getString("NamaKategori"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
}
