package Master;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class Supplier {
    private int id;
    private String name;
    private String address;
    private String phone;
    private String email;
    private int status;
    Controller ctrl = new Controller();
    DBConnect connect = new DBConnect();

    public Supplier(int id, String name, String address, String phone, String email, int status) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.status = status;
    }
    public Supplier(){}

    public int getIdSupplier() {return id;}
    public void setId(int id) {this.id = id;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
    public String getAddress() {return address;}
    public void setAddress(String address) {this.address = address;}
    public String getPhone() {return phone;}
    public void setPhone(String phone) {this.phone = phone;}
    public String getEmail() {return email;}
    public void setStatus(int status) {this.status = status;}
    public int getStatus() {return status;}
    public void setEmail(String email) {this.email = email;}

    public List<Supplier> getSupplier(String comboBox, String search){
        List<Supplier> suppliers = new ArrayList<>();
        try{
            String view = "SELECT * FROM dbo.FnSearchSupplier(?,?)";
            connect.pstat = connect.conn.prepareStatement(view);
            connect.pstat.setString(1,comboBox);
            connect.pstat.setString(2,search);
            connect.result = connect.pstat.executeQuery();
            while (connect.result.next()){
                suppliers.add(Result(connect.result));
            }
            connect.pstat.close();
            connect.result.close();
        }catch (SQLException e){
            ctrl.alertError("Error :"+e.getMessage());
        }
        return suppliers;
    }
    public Supplier Result(ResultSet result) throws SQLException {
        return new Supplier(result.getInt("id_supplier"), result.getString("NamaSupplier"),
                result.getString("Alamat"), result.getString("NoTelepon"),
                result.getString("Email"), result.getInt("Status"));
    }
//
    // Auto Id
    public void getIdSupplier(TextField tfID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Supplier";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_supplier");
            }
            connect.stat.close();
            connect.result.close();
            tfID.setText(String.format("SPR%02d",id+1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
    // Name Supplier For Cb
    public void getNameSupplier(ComboBox cb){
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Supplier";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                cb.getItems().add(connect.result.getString("NamaSupplier"));
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
    // Name Supplier By Id
    public String getNameSupplier(int id) {
        String nama = "";
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM Supplier WHERE id_supplier = " + id;
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                nama = connect.result.getString("NamaSupplier");
            }
            connect.stat.close();
            connect.result.close();
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
        return nama;
    }
    // Id Supplier By Name
    public int getIdSupplier(String value) {
        int id=0;
        try {
            connect.cstat = connect.conn.prepareCall("{ ? = call GetSupplierIdByName(?) }");
            connect.cstat.setString(2, value);
            connect.cstat.registerOutParameter(1, java.sql.Types.INTEGER);
            connect.cstat.execute();
            id = connect.cstat.getInt(1);
        } catch (SQLException ex) {
            ctrl.alertError("Error :"+ex.getMessage());
        }
        return id;
    }
}
