package Nav;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Navigation {
    public void changePage(ActionEvent event, String path){
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();//buat stage

        //untuk memudahkan pindah page
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource(path+".fxml"));
            System.out.println(root);
        } catch (IOException e) {
            e.printStackTrace();
        }

        stage.setScene(new Scene(root,900,600));//atur scene
        stage.setFullScreen(true);
        stage.show();

    }
    public void changePage(Stage stage,String path){

        //untuk memudahkan pindah page
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource(path+".fxml"));
            System.out.println(root);
        } catch (IOException e) {
            e.printStackTrace();
        }

        stage.setScene(new Scene(root,900,600));//atur scene
        stage.setFullScreen(true);
        stage.show();

    }
}
