package SuperClassInterface;

public interface CRUD {
    void insertData();
    void updateData();
    void deleteData(int id);
    void detailData(int id);
}
