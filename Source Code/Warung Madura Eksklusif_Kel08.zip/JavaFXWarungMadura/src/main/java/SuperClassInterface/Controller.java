package SuperClassInterface;

import Controller.MasterC.*;
import Controller.TransactionC.PurchaseC;
import javafx.animation.PauseTransition;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.util.Duration;

import java.awt.*;
import java.io.File;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class Controller {
    private EmployeeC employeeC;
    private PositionC positionC;
    private ProductCategoryC productCategoryC;
    private DistributorC supplierC;
    private ProductC productC;
    private PurchaseC purchaseC;
    private Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    private double screenWidth = screenSize.getWidth();
    private double screenHeight = screenSize.getHeight();
    private NumberFormat rupiahFormat = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));


    public void setController(EmployeeC controller) {
        this.employeeC = controller;
    }
    public void setController(PositionC controller) {
        this.positionC = controller;
    }
    public void setController(ProductCategoryC controller) {
        this.productCategoryC = controller;
    }
    public void setController(DistributorC controller) {
        this.supplierC = controller;
    }
    public void setController(ProductC controller) {
        this.productC = controller;
    }
    public void setController(PurchaseC controller) {
        this.purchaseC = controller;
    }
    public void handleImport(Stage stage, FileChooser fileChooser) {
        fileChooser.setTitle("Open Resource File");
        fileChooser.setInitialDirectory(new File("C:\\"));
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("JPEG image", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG image", "*.png"), new FileChooser.ExtensionFilter("All images", "*.jpg", "*.png"));
    }
    public void deleteList(VBox card_container) {
        card_container.getChildren().removeAll(card_container.getChildren());
    }
    public void deleteList(GridPane card_container) {
        card_container.getChildren().removeAll(card_container.getChildren());
    }
    public void setNumber(KeyEvent e) {
        String character = e.getCharacter();
        if (!character.matches("[0-9]") && !character.equals("\b") && !character.equals("\n")) {
            e.consume();
        }
    }
    public void setDecimal(KeyEvent e) {
        String character = e.getCharacter();
        if (!character.matches("[0-9]") && !character.equals("\b") && !character.equals(".")) {
            e.consume();
        }
    }
    public void setAlphabet(KeyEvent e) {
        String character = e.getCharacter();
        if (!character.matches("[a-zA-Z]") && !character.equals("\b") && !character.equals(" ")) {
            e.consume();
        }
    }
//    public void formatRupiah(TextField field) {
//        DecimalFormat decimalFormat = new DecimalFormat("#,##0");
//        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
//        String textField = field.getText();
//        String input = textField.replace("Rp", "").replace(".", "").trim();
//        int caretPosition = field.getCaretPosition();
//        if (input.isEmpty()) {
//            field.setText("Rp ");
//            field.positionCaret(3);
//            return;
//        }
//
//        try {
//            double value = Double.parseDouble(input.replace(',', '.'));
//            String formatted = decimalFormat.format(value);
//            String newtext = "Rp " + formatted;
//            field.setText(newtext);
//            int newCaretPosition = Math.min(caretPosition,newtext.length());
//            field.positionCaret(newCaretPosition);
//        } catch (NumberFormatException ex) {
//            field.setText("Rp ");
//            field.positionCaret(3);
//        }
//    }
    public void popup(Pane popup, Label desk, String deskripsi) {
        popup.setVisible(true);
        desk.setText(deskripsi);
        PauseTransition visiblePause = new PauseTransition(Duration.seconds(2));
        visiblePause.setOnFinished(event -> popup.setVisible(false));
        visiblePause.play();
    }
    public double getScreenHeight() {
        return screenHeight;
    }
    public double getScreenWidth() {
        return screenWidth;
    }
    public void alertInfo(String message){
        Alert infoAlert = new Alert(AlertType.INFORMATION);
        infoAlert.setTitle("Information");
        infoAlert.setHeaderText(null);
        infoAlert.setContentText(message);
        infoAlert.showAndWait();
    }
    public void alertWarning(String message){
        Alert warningAlert = new Alert(AlertType.WARNING);
        warningAlert.setTitle("Warning");
        warningAlert.setHeaderText(null);
        warningAlert.setContentText(message);
        warningAlert.showAndWait();
    }

    public void alertError(String message){
        Alert errorAlert = new Alert(AlertType.ERROR);
        errorAlert.setTitle("Error");
        errorAlert.setHeaderText(null);
        errorAlert.setContentText(message);
        errorAlert.showAndWait();
    }
    public boolean alertConfirm(String message){
        AtomicBoolean result = new AtomicBoolean(false);
        Alert confirmAlert = new Alert(AlertType.CONFIRMATION);
        confirmAlert.setTitle("Confirmation");
        confirmAlert.setHeaderText(null);
        confirmAlert.setContentText(message);
        confirmAlert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                result.set(true);
            } else {
                result.set(false);
            }
        });
        return result.get();
    }
    public String formatRp(double amount) {
        Locale indonesia = new Locale("id", "ID");
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(indonesia);
        String formattedAmount = currencyFormatter.format(amount);
        if (formattedAmount.contains("Rp")) {
            formattedAmount = formattedAmount.replace("Rp", "Rp. ");
        } else {
            formattedAmount = "Rp. " + formattedAmount;
        }
        return formattedAmount;
    }
    public String formatRp(BigDecimal amount) {
        Locale indonesia = new Locale("id", "ID");
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(indonesia);
        String formattedAmount = currencyFormatter.format(amount);
        if (formattedAmount.contains("Rp")) {
            formattedAmount = formattedAmount.replace("Rp", "Rp. ");
        } else {
            formattedAmount = "Rp. " + formattedAmount;
        }
        return formattedAmount;
    }
    public double parseRp(String amount) {
        double db = Double.parseDouble(amount.replace("Rp. ", "").replace(",00", "").replace(".", ""));
        return db;
    }
    public BigDecimal parseRp(String amount, int s) {
        String cleanedAmount = amount.replace("Rp. ", "").replace(",00", "").replace(".", "").replaceAll("\\s", "");
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("id", "ID"));
        String decimalSeparator = Character.toString(symbols.getDecimalSeparator());
        cleanedAmount = cleanedAmount.replace(",", decimalSeparator);
        BigDecimal db = new BigDecimal(cleanedAmount);
        return db;
    }
}