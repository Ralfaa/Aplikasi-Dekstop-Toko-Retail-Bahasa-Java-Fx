package Transaction;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Purchase {
    private int purchaseID;
    private int supplierID;
    private int employeeID;
    private Date purchaseDate;
    private double totalPrice;
    DBConnect connect = new DBConnect();
    Controller ctrl = new Controller();

    public int getPurchaseID() {return purchaseID;}
    public void setPurchaseID(int purchaseID) {this.purchaseID = purchaseID;}
    public int getSupplierID() {return supplierID;}
    public void setSupplierID(int supplierID) {this.supplierID = supplierID;}
    public int getEmployeeID() {return employeeID;}
    public void setEmployeeID(int employeeID) {this.employeeID = employeeID;}
    public Date getPurchaseDate() {return purchaseDate;}
    public void setPurchaseDate(Date purchaseDate) {this.purchaseDate = purchaseDate;}
    public double getTotalPrice() {return totalPrice;}
    public void setTotalPrice(double totalPrice) {this.totalPrice = totalPrice;}
    public Purchase(int purchaseID, int supplierID, int employeeID, Date purchaseDate, double totalPrice) {
        this.purchaseID = purchaseID;
        this.supplierID = supplierID;
        this.employeeID = employeeID;
        this.purchaseDate = purchaseDate;
        this.totalPrice = totalPrice;
    }
    public Purchase(){}

    public List<Purchase> getPurchaseList(){
        List<Purchase> purchaseList = new ArrayList<>();
        return purchaseList;
    }

    // Auto Id
    public void getIdPurchaseTrs(Label lbID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM TransaksiPembelian";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_transaksi_pembelian");
            }
            connect.stat.close();
            connect.result.close();
            lbID.setText(String.format("POD%03d",id+1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
}
