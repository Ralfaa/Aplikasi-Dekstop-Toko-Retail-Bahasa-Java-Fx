package Transaction;

import Connection.DBConnect;
import SuperClassInterface.Controller;
import javafx.scene.control.Label;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Sale {
    private int saleID;
    private int promoID;
    private int employeeID;
    private int memberID;
    private Date purchaseDate;
    private double totalPrice;
    DBConnect connect = new DBConnect();
    Controller ctrl = new Controller();

    public int getSaleID() {return saleID;}
    public void setSaleID(int saleID) {this.saleID = saleID;}
    public int getPromoID() {return promoID;}
    public void setPromoID(int promoID) {this.promoID = promoID;}
    public int getEmployeeID() {return employeeID;}
    public void setEmployeeID(int employeeID) {this.employeeID = employeeID;}
    public Date getPurchaseDate() {return purchaseDate;}
    public void setPurchaseDate(Date purchaseDate) {this.purchaseDate = purchaseDate;}
    public double getTotalPrice() {return totalPrice;}
    public void setTotalPrice(double totalPrice) {this.totalPrice = totalPrice;}
    public int getMemberID() {return memberID;}
    public void setMemberID(int memberID) {this.memberID = memberID;}

    public Sale(int saleID, int promoID, int employeeID, Date purchaseDate, double totalPrice) {
        this.saleID = saleID;
        this.promoID = promoID;
        this.employeeID = employeeID;
        this.purchaseDate = purchaseDate;
        this.totalPrice = totalPrice;
    }
    public Sale(){}

    public void getIdSaleTrs(Label lbID) {
        int id = 0;
        try {
            connect.stat = connect.conn.createStatement();
            String view = "SELECT * FROM TransaksiPenjualan";
            connect.result = connect.stat.executeQuery(view);
            while (connect.result.next()) {
                id = connect.result.getInt("id_transaksi_penjualan");
            }
            connect.stat.close();
            connect.result.close();
            lbID.setText(String.format("SNT%03d",id+1));
        } catch (SQLException e) {
            ctrl.alertError("Error :"+e.getMessage());
        }
    }
}
