module warungmadura.warungmadura {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.desktop;
    requires java.logging;
    requires javafx.graphics;
    requires java.sql;
    requires mssql.jdbc;
    requires jasperreports;
    requires jfreechart;


    exports Controller.App to javafx.graphics;
    opens Controller.App to javafx.fxml;
    opens Master;
    exports Controller.LandingPage to javafx.graphics;
    opens Controller.LandingPage to javafx.fxml;
    exports Controller.TransactionC to javafx.graphics;
    opens Controller.TransactionC to javafx.fxml;
    exports Controller.Pages to javafx.graphics;
    opens Controller.Pages to javafx.fxml, javafx.base;
    exports Controller.MasterC to javafx.graphics;
    opens Controller.MasterC to javafx.fxml;
    exports Controller.Component to javafx.graphics;
    opens Controller.Component to javafx.fxml;
}